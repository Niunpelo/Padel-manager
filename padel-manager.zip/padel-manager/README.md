# Padel Manager

Juego de gestión de pádel para el móvil. Diriges un club, entrenas a tus jugadores, fichas técnicos y compites en torneos con una pareja masculina y otra femenina. Cada pista tiene sus condiciones (rápida o lenta, cubierta o con calor y viento) y decide qué parejas rinden mejor.

Es una app web (HTML, CSS y JavaScript sin dependencias) empaquetada como app de Android con [Capacitor](https://capacitorjs.com). La partida se guarda en el propio móvil.

## Probarlo en el ordenador

Abre `www/index.html` en el navegador, o arranca un servidor local:

```
npm run serve
```

y entra en http://localhost:8080. Si lo ves en el ordenador, reduce la ventana a tamaño móvil.

Para comprobar el motor de partidos: `npm test`.

## Sacar el APK con GitHub

1. **Crea un repositorio** en github.com (botón *New*). Puede ser privado.
2. **Sube todo el contenido de esta carpeta.**
   - Con git, desde dentro de la carpeta:
     ```
     git init
     git add .
     git commit -m "Padel Manager"
     git branch -M main
     git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
     git push -u origin main
     ```
   - Sin git: en el repositorio, *uploading an existing file* y arrastra todo. Asegúrate de que sube la carpeta oculta `.github`. Si no aparece, créala a mano: *Add file, Create new file*, escribe el nombre `.github/workflows/build-apk.yml` y pega el contenido de ese archivo.
3. **Espera la compilación.** Entra en la pestaña *Actions*. El flujo *Compilar APK* arranca solo al subir los archivos. Si GitHub pide activar los flujos, pulsa el botón verde. La primera vez tarda unos 5 a 10 minutos.
4. **Descarga el APK.** En la página principal del repositorio, a la derecha, entra en *Releases* y abre la última compilación. Descarga `padel-manager.apk`, mejor desde el propio móvil. También lo tienes dentro de la ejecución en *Actions*, apartado *Artifacts*.
5. **Instálalo.** Abre el archivo descargado. Android te pedirá permiso para instalar apps de ese origen (navegador o gestor de archivos). Acepta y pulsa *Instalar*.

Cada vez que cambies algo y lo subas, se genera un APK nuevo. Puedes lanzarlo también a mano con *Run workflow* en *Actions*. Todos los APK van firmados con la misma clave (`resources/debug.keystore`), así que el nuevo se instala encima del anterior y conserva tu partida.

El APK es de prueba, firmado con la clave de depuración de Android. Sirve para instalarlo en tu móvil o pasarlo a amigos. Para publicarlo en Google Play haría falta una firma propia y un paquete `.aab`, que no están incluidos.

### Si la compilación falla

Abre la ejecución marcada con la cruz roja, entra en el paso que falló y copia las últimas líneas del registro. Este flujo sigue el camino estándar de Capacitor, pero no se pudo ejecutar en GitHub al prepararlo, así que puede necesitar un retoque.

## Cómo está organizado

```
www/                 el juego (lo que ve el móvil)
  index.html
  css/styles.css
  js/engine.js       reglas: jugadores, pistas, simulación de partidos y cuadros
  js/data.js         cuerpo técnico, instalaciones, escudos
  js/svg.js          pista, radar de estadísticas, iconos
  js/app.js          pantallas, estado de la partida, guardado
resources/           icono de la app (icon.svg es el original)
scripts/             personaliza el proyecto Android al compilar
test/                pruebas del motor
capacitor.config.json  nombre e identificador de la app
.github/workflows/   compilación automática del APK
```

## Cómo funciona el juego

- **Jugadores:** ocho estadísticas (remate, volea, bandeja, defensa, globo, saque, aguante, mente), lado de pista (drive o revés), rasgos y cansancio.
- **Parejas:** cada torneo presentas dos hombres y dos mujeres. Un drive con un revés suma sinergia, y un atacante con un defensivo también.
- **Pistas:** en una pista rápida pesa más el ataque. En una lenta, la defensa. El cristal vivo ayuda a defender, el calor sube el cansancio y el viento complica globos y bandejas.
- **Tácticas:** agresiva, equilibrada o conservadora. Cambian el rendimiento, el riesgo y el cansancio.
- **Torneos:** cuadros de 16 parejas por categoría, a tres sets con punto de oro. Los jugadores acumulan cansancio de ronda en ronda.
- **Club:** cada semana puedes jugar uno de dos torneos o descansar. Con el dinero ficha técnicos, mejora instalaciones y compra jugadores. Los puntos del circuito te hacen subir de Bronce a Plata y a Oro.

## Cosas que querrás cambiar

- **Nombre de la app:** `appName` en `capacitor.config.json`.
- **Equilibrio del juego:** constantes al principio de `js/engine.js` (`SCALE`, `TIER_AT`, `TIER_FIELD`, `PRIZE_BASE`) y costes en `js/data.js`.
- **Icono:** edita `resources/icon.svg` y vuelve a exportar los PNG de `resources/android/res`.
- **Tipografía:** usa la fuente condensada del sistema (en Android, Roboto Condensed). Para una fuente propia, copia un `.woff2` a `www/fonts`, decláralo con `@font-face` en `css/styles.css` y ponlo al principio de `--disp`.

## Siguientes pasos posibles

- Modo online asíncrono: torneos programados cada cierto tiempo, con parejas de otros jugadores. El servidor solo tiene que guardar las inscripciones y simular los cuadros, así que un servicio como Supabase o Firebase basta al principio.
- Temporadas con ascensos y descensos, lesiones, patrocinadores y estadios propios.
- Más tipos de pista y torneos con superficies especiales.
