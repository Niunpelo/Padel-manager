/* Pruebas rápidas del motor: node test/engine.test.js */
const PM = require('../www/js/engine.js');
const assert = require('assert');

const rng = PM.makeRng(12345);
let ok = 0;
const t = (name, fn) => { fn(); ok++; console.log('  ✓', name); };

function pairOf(ovr, archs, sides) {
  const players = [0, 1].map((i) => PM.makePlayer(rng, { gender: 'M', ovr, arch: archs[i], side: sides[i], traitChance: 0, age: 25 }));
  return { id: 'x' + Math.random(), isUser: false, players, tactic: 'equilibrada', synBonus: 0, fatMult: 1 };
}

console.log('Motor de simulación');

t('un partido tiene resultado válido', () => {
  const A = pairOf(55, ['atacante', 'defensivo'], ['drive', 'reves']);
  const B = pairOf(55, ['atacante', 'defensivo'], ['drive', 'reves']);
  const t1 = PM.makeTournament(rng, 0);
  for (let i = 0; i < 300; i++) {
    const r = PM.simulateMatch(A, B, t1.court, rng);
    assert(r.sets.length === 2 || r.sets.length === 3);
    let wa = 0, wb = 0;
    r.sets.forEach(([a, b]) => {
      assert(Math.max(a, b) === 6 && Math.min(a, b) <= 4 || Math.max(a, b) === 7 && (Math.min(a, b) === 5 || Math.min(a, b) === 6), 'set raro ' + a + '-' + b);
      if (a > b) wa++; else wb++;
    });
    assert((wa === 2 && r.winner === 'A') || (wb === 2 && r.winner === 'B'));
  }
});

console.log('\nProbabilidad de ganar el partido según diferencia de nivel (misma pista media)');
const court = { speed: 0.5, bounce: 0.5, indoor: true, temp: 22, wind: 0, ball: 'nueva' };
[0, 2, 4, 6, 8, 12].forEach((d) => {
  const N = 1500;
  let w = 0;
  for (let i = 0; i < N; i++) {
    const A = pairOf(55 + d, ['atacante', 'defensivo'], ['drive', 'reves']);
    const B = pairOf(55, ['atacante', 'defensivo'], ['drive', 'reves']);
    if (PM.simulateMatch(A, B, court, rng).winner === 'A') w++;
  }
  console.log('  +' + d + ' de media → gana ' + Math.round(100 * w / N) + '%');
});

console.log('\nEfecto de la pista: atacante puro vs defensivo puro (mismo nivel)');
[['rápida', 0.85, 0.5], ['lenta', 0.15, 0.5], ['media', 0.5, 0.5]].forEach(([n, sp, bo]) => {
  const c = { speed: sp, bounce: bo, indoor: true, temp: 22, wind: 0, ball: 'nueva' };
  const N = 1500; let w = 0;
  for (let i = 0; i < N; i++) {
    const A = pairOf(55, ['atacante', 'atacante'], ['drive', 'reves']);
    const B = pairOf(55, ['defensivo', 'defensivo'], ['drive', 'reves']);
    if (PM.simulateMatch(A, B, c, rng).winner === 'A') w++;
  }
  console.log('  pista ' + n + ': los atacantes ganan ' + Math.round(100 * w / N) + '%');
});

console.log('\nTorneo completo (cuadro de 16) con pareja del jugador de nivel X, circuito Bronce');
[44, 48, 52, 56, 60].forEach((ovr) => {
  const N = 300;
  const hist = [0, 0, 0, 0, 0];
  for (let i = 0; i < N; i++) {
    const tour = PM.makeTournament(rng, 0);
    const users = [0, 1].map(() => PM.makePlayer(rng, { gender: 'M', ovr, traitChance: 0.3, age: 24 }));
    users[0].side = 'drive'; users[1].side = 'reves';
    const up = { id: 'USER', isUser: true, players: users, tactic: PM.suggestTactic(users, tour.court), synBonus: 0, fatMult: 1 };
    const draw = PM.makeDraw(rng, { gender: 'M', tier: 0, userPair: up });
    while (!draw.done) {
      up.tactic = PM.suggestTactic(users, tour.court);
      PM.playRound(draw, tour.court, rng);
    }
    hist[draw.exit.USER]++;
  }
  const lbl = PM.EXIT_LABEL;
  console.log('  nivel ' + ovr + ': ' + hist.map((h, i) => lbl[i] + ' ' + Math.round(100 * h / N) + '%').join(' · '));
});

console.log('\nTorneo para pareja en circuito Plata/Oro con nivel adecuado');
[[1, 62], [2, 75]].forEach(([tier, ovr]) => {
  const N = 200; const hist = [0, 0, 0, 0, 0];
  for (let i = 0; i < N; i++) {
    const tour = PM.makeTournament(rng, tier);
    const users = [0, 1].map(() => PM.makePlayer(rng, { gender: 'F', ovr, traitChance: 0.3, age: 24 }));
    users[0].side = 'drive'; users[1].side = 'reves';
    const up = { id: 'USER', isUser: true, players: users, tactic: 'equilibrada', synBonus: 0, fatMult: 1 };
    const draw = PM.makeDraw(rng, { gender: 'F', tier, userPair: up });
    while (!draw.done) PM.playRound(draw, tour.court, rng);
    hist[draw.exit.USER]++;
  }
  console.log('  tier ' + tier + ' nivel ' + ovr + ': ' + hist.map((h, i) => PM.EXIT_LABEL[i] + ' ' + Math.round(100 * h / N) + '%').join(' · '));
});

t('entrenar sube estadísticas con el tiempo', () => {
  const p = PM.makePlayer(rng, { gender: 'M', ovr: 50, age: 20 });
  p.focus = 'remate';
  const b = p.stats.remate;
  for (let i = 0; i < 20; i++) PM.trainWeek(p, { tec: 2, tac: 0, fis: 0, pistas: 1 }, rng);
  assert(p.stats.remate > b + 8, 'sube poco: ' + (p.stats.remate - b));
});

console.log('\n' + ok + ' pruebas correctas');
