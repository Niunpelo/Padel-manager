/*
 * Personaliza el proyecto Android que genera Capacitor (`npx cap add android`).
 * Lo ejecuta el flujo de GitHub, pero también puedes lanzarlo tú: node scripts/patch-android.js
 *
 * Qué hace:
 *  1. Pone el icono de la app (iconos normales y adaptativos).
 *  2. Pone color azul a la barra de estado y al fondo del icono.
 *  3. Cambia la pantalla de carga blanca por un fondo azul oscuro.
 *  4. Evita que la app se dibuje debajo de la barra de estado en Android 15 o superior.
 *
 * Cada paso es independiente: si un archivo no existe, se salta y la compilación sigue.
 */
const fs = require('fs');
const path = require('path');

const root = process.cwd();
const res = path.join(root, 'android', 'app', 'src', 'main', 'res');

if (!fs.existsSync(res)) {
  console.error('No existe ' + res + '. Ejecuta antes: npx cap add android');
  process.exit(1);
}

function patch(rel, fn) {
  const file = path.join(res, rel);
  if (!fs.existsSync(file)) { console.log('  (se salta, no existe) ' + rel); return; }
  const before = fs.readFileSync(file, 'utf8');
  const after = fn(before);
  if (after !== before) { fs.writeFileSync(file, after); console.log('  modificado ' + rel); }
  else console.log('  sin cambios ' + rel);
}

function copyDir(from, to) {
  if (!fs.existsSync(from)) return 0;
  let n = 0;
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    const a = path.join(from, e.name), b = path.join(to, e.name);
    if (e.isDirectory()) { fs.mkdirSync(b, { recursive: true }); n += copyDir(a, b); }
    else { fs.copyFileSync(a, b); n++; }
  }
  return n;
}

function walk(dir, out) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else out.push(p);
  }
  return out;
}

console.log('1. Iconos');
console.log('  ' + copyDir(path.join(root, 'resources', 'android', 'res'), res) + ' archivos copiados');

console.log('2. Colores');
patch('values/colors.xml', (s) => s
  .replace(/(<color name="colorPrimary">)[^<]*/, '$1#0C2760')
  .replace(/(<color name="colorPrimaryDark">)[^<]*/, '$1#0C2760'));
patch('values/ic_launcher_background.xml', (s) => s.replace(/(<color name="ic_launcher_background">)[^<]*/, '$1#1E55C6'));

console.log('3. Pantalla de carga');
const splash = path.join(root, 'resources', 'splash.png');
let nSplash = 0;
if (fs.existsSync(splash)) {
  walk(res, []).filter((p) => path.basename(p) === 'splash.png').forEach((p) => { fs.copyFileSync(splash, p); nSplash++; });
}
console.log('  ' + nSplash + ' imágenes sustituidas');

console.log('4. Barra de estado en Android 15 o superior');
patch('values/styles.xml', (s) => {
  if (s.includes('windowOptOutEdgeToEdgeEnforcement')) return s;
  return s.replace(/(<style\s+name="AppTheme[^"]*"[^>]*>)/g, '$1\n        <item name="android:windowOptOutEdgeToEdgeEnforcement">true</item>');
});

console.log('Listo.');
