/* Piezas visuales en SVG: iconos, escudo, pista y radar de estadísticas. */
window.PM_UI = (function () {
  'use strict';
  const PM = window.PM;

  const ICONS = {
    club: '<path d="M12 3l7 3v5.5c0 4.6-3 7.7-7 9.5-4-1.8-7-4.9-7-9.5V6z"/><path d="M12 8v8M8.5 12h7"/>',
    players: '<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.5 2.7-6 6-6s6 2.5 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M16.2 14.2c2.9.2 4.8 2.2 4.8 5.3"/>',
    academy: '<path d="M2.5 9.5L12 5l9.5 4.5L12 14z"/><path d="M6.5 11.8V16c0 1.4 2.5 2.8 5.5 2.8s5.5-1.4 5.5-2.8v-4.2"/><path d="M21.5 9.5V15"/>',
    market: '<path d="M4 8h13.5M14.5 4.8L17.7 8l-3.2 3.2"/><path d="M20 16H6.5M9.5 12.8L6.3 16l3.2 3.2"/>',
    trophy: '<path d="M7.5 4h9v5.2a4.5 4.5 0 01-9 0z"/><path d="M7.5 6H4.3v1.7a3.3 3.3 0 003.2 3.3M16.5 6h3.2v1.7a3.3 3.3 0 01-3.2 3.3"/><path d="M12 13.7V18M8.3 20.5h7.4M9.5 18h5"/>',
    bolt: '<path d="M13 3L5.5 13.5H11L10 21l8-11h-5.5z"/>',
    glass: '<rect x="4" y="4" width="16" height="16" rx="1.5"/><path d="M9 4v16M4 12h5"/>',
    roof: '<path d="M3 11l9-6.5L21 11"/><path d="M5.5 10v9.5h13V10"/><path d="M10 19.5v-5h4v5"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6L7 7M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/>',
    therm: '<path d="M10 14.3V5.5a2 2 0 114 0v8.8a4 4 0 11-4 0z"/>',
    wind: '<path d="M3 9h10a2.6 2.6 0 10-2.6-2.6M3 13h14a3 3 0 11-3 3M3 17h6"/>',
    ball: '<circle cx="12" cy="12" r="8.5"/><path d="M4 9.5c4.5 1.4 11.5 1.4 16 0M4 14.5c4.5-1.4 11.5-1.4 16 0"/>',
    heart: '<path d="M12 20s-7-4.4-7-9.7A4 4 0 0112 8a4 4 0 017 2.3C19 15.6 12 20 12 20z"/>',
    back: '<path d="M15 5l-7 7 7 7"/>',
    moon: '<path d="M19 14.5A7.5 7.5 0 019.5 5a7.5 7.5 0 109.5 9.5z"/>'
  };
  function icon(name, cls) {
    return '<svg viewBox="0 0 24 24" aria-hidden="true"' + (cls ? ' class="' + cls + '"' : '') + '>' + (ICONS[name] || '') + '</svg>';
  }

  function crest(club, size) {
    const c = club.crest || { a: '#1E55C6', b: '#DDEB3B' };
    const ini = (club.name || 'C').trim().charAt(0).toUpperCase();
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 48 52" aria-hidden="true">' +
      '<path d="M24 2l19 7v15c0 12-8 20-19 26C13 44 5 36 5 24V9z" fill="' + c.a + '" stroke="#fff" stroke-width="2.5"/>' +
      '<path d="M24 2v48" stroke="' + c.b + '" stroke-width="2" opacity=".55"/>' +
      '<text x="24" y="33" text-anchor="middle" font-family="Arial Narrow, sans-serif-condensed, sans-serif" font-weight="800" font-style="italic" font-size="25" fill="' + c.b + '">' + esc(ini) + '</text></svg>';
  }
  function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

  function sideIcon(side) {
    const x = side === 'drive' ? 10 : 1;
    return '<svg class="sideic" viewBox="0 0 20 24" aria-hidden="true"><rect x="1" y="1" width="18" height="22" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/>' +
      '<rect x="' + x + '" y="1" width="9" height="22" fill="currentColor" opacity=".4"/><path d="M10 1v22M1 12h18" stroke="currentColor" stroke-width="1.2" fill="none"/></svg>';
  }

  function fatClass(f) { return f >= 66 ? 'hi' : f >= 36 ? 'mid' : ''; }
  function fatBar(f) { return '<div class="fat" role="img" aria-label="Cansancio ' + Math.round(f) + '%"><i class="' + fatClass(f) + '" style="width:' + Math.max(2, Math.round(f)) + '%"></i></div>'; }

  let courtN = 0;
  /* Pista vista desde arriba. Color, rebote, viento y calor salen de las condiciones reales. */
  function courtSvg(c) {
    const id = 'ct' + (courtN++);
    const sp = c.speed, bo = c.bounce;
    const hue = 224 - sp * 12, light = 33 + sp * 17;
    const floor = 'hsl(' + hue.toFixed(0) + ' 68% ' + light.toFixed(0) + '%)';
    const around = 'hsl(' + (hue - 4).toFixed(0) + ' 62% ' + (light - 15).toFixed(0) + '%)';
    const heat = !c.indoor && c.temp >= 27 ? Math.min(0.3, (c.temp - 26) / 38) : 0;
    const cold = !c.indoor && c.temp <= 14 ? Math.min(0.22, (15 - c.temp) / 24) : 0;
    const wn = c.indoor ? 0 : Math.min(1, c.wind / 30);

    // trayectoria de la bola: suelo -> cristal del fondo -> vuelve según el rebote
    const endY = 4 + 40 + 100 * bo * (0.55 + sp * 0.55);
    const endX = 30 - 8 * bo + 10 * (1 - sp);
    const path = 'M26 178 L58 54 L76 2 L' + endX.toFixed(0) + ' ' + endY.toFixed(0);

    let s = '<svg class="court-svg" viewBox="-12 -14 124 228" role="img" aria-label="Pista vista desde arriba">';
    s += '<defs>' +
      '<pattern id="' + id + 'g" width="4" height="4" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".6" fill="#fff" opacity=".12"/><circle cx="3" cy="3" r=".6" fill="#000" opacity=".1"/></pattern>' +
      '<pattern id="' + id + 'm" width="4" height="4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0v4" stroke="#fff" stroke-width=".7" opacity=".55"/></pattern>' +
      '<radialGradient id="' + id + 'l"><stop offset="0" stop-color="#fff" stop-opacity=".30"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>' +
      '</defs>';
    s += '<rect x="-12" y="-14" width="124" height="228" fill="' + around + '"/>';
    s += '<rect x="0" y="0" width="100" height="200" fill="' + floor + '"/><rect x="0" y="0" width="100" height="200" fill="url(#' + id + 'g)"/>';
    if (c.indoor) s += '<circle cx="28" cy="56" r="44" fill="url(#' + id + 'l)"/><circle cx="72" cy="144" r="44" fill="url(#' + id + 'l)"/>';
    if (heat) s += '<rect x="0" y="0" width="100" height="200" fill="#ff8a1f" opacity="' + heat.toFixed(2) + '"/>';
    if (cold) s += '<rect x="0" y="0" width="100" height="200" fill="#cfe4ff" opacity="' + cold.toFixed(2) + '"/>';
    // cristal del fondo y malla lateral
    s += '<rect x="0" y="-8" width="100" height="8" fill="#fff" opacity=".28"/><rect x="0" y="200" width="100" height="8" fill="#fff" opacity=".28"/>';
    s += '<rect x="-5" y="0" width="5" height="200" fill="url(#' + id + 'm)"/><rect x="100" y="0" width="5" height="200" fill="url(#' + id + 'm)"/>';
    // líneas
    s += '<g fill="none" stroke="#fff" stroke-width="1.7" stroke-linecap="square"><rect x="0" y="0" width="100" height="200"/>' +
      '<path d="M0 30.5h100M0 169.5h100M50 30.5V100M50 100v69.5"/></g>';
    // red
    s += '<path d="M-6 100h112" stroke="#eaf1ff" stroke-width="3.2"/><circle cx="-6" cy="100" r="2.4" fill="#eaf1ff"/><circle cx="106" cy="100" r="2.4" fill="#eaf1ff"/>';
    // viento
    for (let i = 0; i < Math.ceil(wn * 3); i++) {
      const y = 40 + i * 50;
      s += '<g class="wind-l" opacity=".85"><path d="M8 ' + y + 'h' + (28 + wn * 40).toFixed(0) + '" stroke="#fff" stroke-width="1.6" stroke-linecap="round" fill="none"/>' +
        '<path d="M' + (36 + wn * 40).toFixed(0) + ' ' + (y - 3) + 'l4 3-4 3" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/></g>';
    }
    // bola
    s += '<path d="' + path + '" fill="none" stroke="#fff" stroke-width="1.6" stroke-dasharray="3.5 3.5" opacity=".8"/>';
    s += '<circle cx="' + endX.toFixed(0) + '" cy="' + endY.toFixed(0) + '" r="5.2" fill="#ddeb3b" stroke="#fff" stroke-width="1"/>' +
      '<path d="M' + (endX - 4).toFixed(0) + ' ' + (endY - 1.5).toFixed(0) + 'q4 3.2 8 0" stroke="#fff" stroke-width=".9" fill="none"/>';
    s += '</svg>';
    return s;
  }

  /* Radar de 8 ejes. Si hay pista, dibuja en discontinua cómo rinde el jugador en ella. */
  function radarSvg(p, court) {
    const S = PM.STATS, N = S.length, R = 84, cx = 130, cy = 128;
    const ang = (i) => -Math.PI / 2 + (i * 2 * Math.PI) / N;
    const fr = (v) => Math.max(0.05, Math.min(1, (v - 20) / 70));
    const pt = (i, v) => [cx + Math.cos(ang(i)) * R * fr(v), cy + Math.sin(ang(i)) * R * fr(v)];
    const poly = (vals) => vals.map((v, i) => pt(i, v).map((n) => n.toFixed(1)).join(',')).join(' ');
    let s = '<svg class="radar" viewBox="-36 0 332 262" role="img" aria-label="Estadísticas de ' + esc(p.name) + '">';
    [40, 60, 80, 90].forEach((v) => {
      s += '<polygon points="' + poly(S.map(() => v)) + '" fill="none" stroke="#c8d4e8" stroke-width="1.2"/>';
    });
    S.forEach((k, i) => {
      const e = pt(i, 90);
      s += '<line x1="' + cx + '" y1="' + cy + '" x2="' + e[0].toFixed(1) + '" y2="' + e[1].toFixed(1) + '" stroke="#c8d4e8" stroke-width="1"/>';
    });
    s += '<polygon points="' + poly(S.map((k) => p.stats[k])) + '" fill="#1e55c6" fill-opacity=".30" stroke="#1e55c6" stroke-width="2.4" stroke-linejoin="round"/>';
    if (court) {
      const eff = PM.effStats(p, court, 0);
      s += '<polygon points="' + poly(S.map((k) => eff[k])) + '" fill="none" stroke="#b4c321" stroke-width="2.4" stroke-dasharray="5 4" stroke-linejoin="round"/>';
    }
    S.forEach((k, i) => {
      const a = ang(i), lx = cx + Math.cos(a) * (R + 24), ly = cy + Math.sin(a) * (R + 22);
      const anchor = Math.abs(Math.cos(a)) < 0.2 ? 'middle' : Math.cos(a) > 0 ? 'start' : 'end';
      const dx = anchor === 'start' ? -6 : anchor === 'end' ? 6 : 0;
      s += '<text x="' + (lx + dx).toFixed(1) + '" y="' + (ly - 1).toFixed(1) + '" text-anchor="' + anchor + '" font-size="11.5" fill="#52617f">' + PM.STAT_LABEL[k] + '</text>' +
        '<text x="' + (lx + dx).toFixed(1) + '" y="' + (ly + 14).toFixed(1) + '" text-anchor="' + anchor + '" font-size="16" font-weight="800" font-style="italic" fill="#0d1a36" font-family="Arial Narrow, sans-serif-condensed, sans-serif">' + Math.round(p.stats[k]) + '</text>';
    });
    return s + '</svg>';
  }

  /* Líneas de pista para fondos (bienvenida y portada del club) */
  function courtLines(cls) {
    return '<svg class="' + cls + '" viewBox="0 0 100 200" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><g fill="none" stroke="#fff" stroke-width="1.4">' +
      '<rect x="6" y="6" width="88" height="188"/><path d="M6 40h88M6 160h88M50 40v120M6 100h88"/></g></svg>';
  }

  return { icon, crest, esc, sideIcon, fatBar, fatClass, courtSvg, radarSvg, courtLines };
})();
