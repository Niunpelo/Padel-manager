/* ============================================================
   Padel Manager · motor del juego
   Sin dependencias. Funciona en el navegador (window.PM) y en Node.
   Aquí vive toda la lógica: jugadores, pistas, simulación, cuadros.
   ============================================================ */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PM = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------- utilidades ---------- */
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const avg = (a) => a.reduce((s, x) => s + x, 0) / a.length;

  function makeRng(seed) {
    let a = (seed >>> 0) || 1;
    const r = function () {
      a |= 0; a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    r.int = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
    r.pick = (arr) => arr[Math.floor(r() * arr.length)];
    r.chance = (p) => r() < p;
    r.gauss = () => {
      let u = 0, v = 0;
      while (u === 0) u = r();
      while (v === 0) v = r();
      return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    };
    r.shuffle = (arr) => {
      const a2 = arr.slice();
      for (let i = a2.length - 1; i > 0; i--) {
        const j = Math.floor(r() * (i + 1));
        [a2[i], a2[j]] = [a2[j], a2[i]];
      }
      return a2;
    };
    return r;
  }

  /* ---------- estadísticas ---------- */
  const STATS = ['remate', 'volea', 'bandeja', 'defensa', 'globo', 'saque', 'aguante', 'mente'];
  const STAT_LABEL = {
    remate: 'Remate', volea: 'Volea', bandeja: 'Bandeja', defensa: 'Defensa',
    globo: 'Globo', saque: 'Saque', aguante: 'Aguante', mente: 'Mente'
  };
  const STAT_HINT = {
    remate: 'Potencia al rematar. Brilla en pistas rápidas.',
    volea: 'Juego en la red. Mejora con pista rápida.',
    bandeja: 'Golpe de control en ataque. El viento la complica.',
    defensa: 'Defensa de pared y salida de cristal. Rinde con cristal vivo.',
    globo: 'Lob para recuperar la red. El viento lo desvía.',
    saque: 'Ventaja en el primer golpe del punto.',
    aguante: 'Cuánto te cansas. Importa en rondas finales y con calor.',
    mente: 'Sangre fría en los puntos clave.'
  };

  const ARCH = {
    atacante: { name: 'Atacante', d: { remate: 12, volea: 9, bandeja: 6, saque: 3, defensa: -10, globo: -8, aguante: -4, mente: -8 } },
    defensivo: { name: 'Defensivo', d: { remate: -10, volea: -8, bandeja: -6, saque: -8, defensa: 12, globo: 10, aguante: 4, mente: 6 } },
    fisico: { name: 'Físico', d: { remate: 2, volea: -6, bandeja: -6, saque: 6, defensa: 4, globo: -8, aguante: 14, mente: -6 } },
    tecnico: { name: 'Técnico', d: { remate: -6, volea: 10, bandeja: 10, saque: -6, defensa: -10, globo: 6, aguante: -8, mente: 4 } },
    completo: { name: 'Completo', d: { remate: 0, volea: 0, bandeja: 0, saque: 0, defensa: 0, globo: 0, aguante: 0, mente: 0 } }
  };
  const ARCH_IDS = Object.keys(ARCH);

  /* ---------- nombres (inventados) ---------- */
  const FIRST_M = ['Álvaro', 'Javi', 'Marcos', 'Nacho', 'Pablo', 'Sergio', 'Lucas', 'Mateo', 'Dani', 'Iván', 'Hugo', 'Raúl', 'Tomás', 'Bruno', 'Adrián', 'Leo', 'Gonzalo', 'Rubén', 'Mario', 'Óscar', 'Santi', 'Fede', 'Matías', 'Franco', 'Joel', 'Ismael', 'Cristian', 'Eloy'];
  const FIRST_F = ['Lucía', 'Marta', 'Paula', 'Carla', 'Irene', 'Sofía', 'Alba', 'Elena', 'Noa', 'Julia', 'Claudia', 'Inés', 'Nuria', 'Aitana', 'Bea', 'Vera', 'Camila', 'Valentina', 'Martina', 'Lola', 'Rocío', 'Sara', 'Gala', 'Abril', 'Ainhoa', 'Minerva', 'Candela', 'Maite'];
  const LAST = ['Ortega', 'Salas', 'Ibáñez', 'Marín', 'Cuesta', 'Duarte', 'Lozano', 'Pizarro', 'Beltrán', 'Varela', 'Cortés', 'Rivas', 'Mendizábal', 'Aranda', 'Quesada', 'Sandoval', 'Barrios', 'Olmedo', 'Escobar', 'Zubiri', 'Peralta', 'Montero', 'Ferrer', 'Bravo', 'Roldán', 'Cabrera', 'Lasa', 'Echeverría', 'Ledesma', 'Valdés', 'Soler', 'Campos', 'Arana', 'Gallego', 'Heredia', 'Ruano', 'Villalba', 'Cienfuegos', 'Amaya', 'Orozco', 'Bermejo', 'Carrasco', 'Domínguez', 'Fontán', 'Garrido', 'Iturbe', 'Lombardi', 'Maldonado', 'Núñez', 'Pardo'];

  /* ---------- rasgos ---------- */
  // mods(c): bonus/malus a estadísticas según la pista. fat(c): multiplicador de cansancio. clutch: ±puntos en tie-break y 3er set.
  const TRAITS = {
    rey_cristal: { name: 'Rey del cristal', good: true, desc: '+8 en defensa si el cristal es vivo.', mods: (c) => (c.bounce > 0.55 ? { defensa: 8 } : null) },
    bombazo: { name: 'Bombazo', good: true, desc: '+8 en remate si la pista es rápida.', mods: (c) => (c.speed > 0.55 ? { remate: 8 } : null) },
    muro: { name: 'Muro', good: true, desc: '+7 en defensa y globo si la pista es lenta.', mods: (c) => (c.speed < 0.45 ? { defensa: 7, globo: 7 } : null) },
    indoor: { name: 'Especialista indoor', good: true, desc: '+5 en remate, volea y bandeja bajo techo.', mods: (c) => (c.indoor ? { remate: 5, volea: 5, bandeja: 5 } : null) },
    marinero: { name: 'Marinero', good: true, desc: 'El viento no le afecta y gana +4 en globo.', mods: (c) => (!c.indoor && c.wind >= 12 ? { globo: 4 + Math.min(14, c.wind / 2.2), bandeja: Math.min(6, c.wind / 4) } : null) },
    sangre_fria: { name: 'Sangre fría', good: true, desc: 'Sube su nivel en tie-breaks y terceros sets.', clutch: 3.5 },
    maraton: { name: 'Maratoniano', good: true, desc: 'Se cansa un 20% menos.', fatBase: 0.8 },
    bochorno: { name: 'Sufre con calor', good: false, desc: 'Con 28º o más pierde aguante y se cansa más.', mods: (c) => (!c.indoor && c.temp >= 28 ? { aguante: -10 } : null), fat: (c) => (!c.indoor && c.temp >= 28 ? 1.25 : 1) },
    fragil: { name: 'Frágil', good: false, desc: 'Se cansa un 20% más.', fatBase: 1.2 },
    nervioso: { name: 'Nervioso', good: false, desc: 'Baja su nivel en tie-breaks y terceros sets.', clutch: -3.5 }
  };
  const TRAIT_IDS = Object.keys(TRAITS);

  function rollTraits(rng, count) {
    const out = [];
    let tries = 0;
    while (out.length < count && tries++ < 12) {
      const id = rng.pick(TRAIT_IDS);
      if (out.includes(id)) continue;
      if (!TRAITS[id].good && out.some((x) => !TRAITS[x].good)) continue;
      out.push(id);
    }
    return out;
  }

  /* ---------- jugadores ---------- */
  function overall(p) {
    return Math.round(avg(STATS.map((s) => p.stats[s])));
  }
  function overallF(p) {
    return avg(STATS.map((s) => p.stats[s]));
  }
  function valueOf(p) {
    const o = overallF(p);
    const youth = Math.max(0, p.pot - o) * 110;
    const oldPen = p.age > 31 ? (p.age - 31) * 500 : 0;
    const v = 1200 + Math.pow(Math.max(0, o - 34), 2) * 14 + youth - oldPen;
    return Math.max(800, Math.round(v / 50) * 50);
  }
  function wageOf(p) {
    return Math.max(60, Math.round(valueOf(p) / 55 / 10) * 10);
  }
  function styleOf(p) {
    const atk = (p.stats.remate + p.stats.volea + p.stats.bandeja) / 3;
    const def = (p.stats.defensa + p.stats.globo) / 2;
    const d = atk - def;
    return d > 7 ? 'ataque' : d < -7 ? 'defensa' : 'mixto';
  }

  let idCounter = 0;
  function uid(rng, prefix) {
    idCounter++;
    return prefix + idCounter.toString(36) + Math.floor(rng() * 46656).toString(36);
  }

  function makePlayer(rng, o) {
    const gender = o.gender || (rng() < 0.5 ? 'M' : 'F');
    const arch = o.arch || rng.pick(ARCH_IDS);
    const target = o.ovr;
    const stats = {};
    STATS.forEach((s) => { stats[s] = target + ARCH[arch].d[s] + rng.gauss() * 3.5; });
    const shift = target - avg(STATS.map((s) => stats[s]));
    STATS.forEach((s) => { stats[s] = clamp(stats[s] + shift, 12, 97); });
    const age = o.age || rng.int(17, 34);
    const first = rng.pick(gender === 'M' ? FIRST_M : FIRST_F);
    const last = o.last || rng.pick(LAST);
    const p = {
      id: uid(rng, 'p'),
      first, last, name: first + ' ' + last,
      gender, age, arch,
      side: o.side || (rng() < 0.5 ? 'drive' : 'reves'),
      stats,
      fatigue: o.fatigue != null ? o.fatigue : 0,
      traits: o.traits || rollTraits(rng, rng.chance(o.traitChance != null ? o.traitChance : 0.45) ? (rng.chance(0.25) ? 2 : 1) : 0),
      focus: null,
      pot: 0
    };
    p.pot = clamp(Math.round(overallF(p) + Math.max(0, 28 - age) * 1.5 + rng.int(0, 7)), Math.round(overallF(p)), 96);
    p.focus = weakest(p);
    return p;
  }
  function weakest(p) {
    return STATS.slice().sort((a, b) => p.stats[a] - p.stats[b])[0];
  }

  /* ---------- pistas ---------- */
  const CITIES = [
    // nombre, temperatura media, viento medio (km/h), probabilidad de pista cubierta
    ['Sevilla', 33, 8, 0.15], ['Málaga', 27, 14, 0.2], ['Valencia', 26, 12, 0.25], ['Bilbao', 16, 12, 0.6],
    ['Madrid', 24, 10, 0.4], ['Barcelona', 23, 15, 0.35], ['Marbella', 29, 18, 0.15], ['Zaragoza', 24, 17, 0.3],
    ['Tenerife', 25, 20, 0.1], ['Palma', 27, 17, 0.2], ['Lisboa', 24, 16, 0.25], ['Oporto', 19, 14, 0.4],
    ['Buenos Aires', 18, 14, 0.4], ['Milán', 20, 8, 0.6], ['Dubái', 38, 12, 0.5], ['Miami', 31, 14, 0.2],
    ['Santiago', 17, 10, 0.5], ['Doha', 37, 10, 0.6]
  ];
  const TIER_NAMES = ['Circuito Bronce', 'Circuito Plata', 'Circuito Oro'];
  const TIER_SHORT = ['Bronce', 'Plata', 'Oro'];
  const TIER_EVENT = ['Open', 'Máster', 'Gran Premio'];
  const TIER_FIELD = [{ mean: 48, sd: 6 }, { mean: 62, sd: 6 }, { mean: 75, sd: 5.5 }];
  const TIER_PRIZE = [1, 2.6, 6];
  const TIER_POINTS = [1, 1.5, 2.2];
  const TIER_AT = [0, 800, 2400]; // puntos para entrar en cada circuito

  function tierForPoints(pts) {
    return pts >= TIER_AT[2] ? 2 : pts >= TIER_AT[1] ? 1 : 0;
  }

  const NEUTRAL = { speed: 0.5, bounce: 0.5, indoor: true, temp: 22, wind: 0, ball: 'media' };

  function speedLabel(s) { return s < 0.36 ? 'Lenta' : s < 0.64 ? 'Media' : 'Rápida'; }
  function bounceLabel(b) { return b < 0.4 ? 'Rebote bajo' : b < 0.65 ? 'Rebote medio' : 'Cristal vivo'; }

  function makeTournament(rng, tier, usedCities) {
    let city;
    let tries = 0;
    do { city = rng.pick(CITIES); } while (usedCities && usedCities.includes(city[0]) && tries++ < 20);
    const indoor = rng.chance(city[3]);
    const ball = rng.pick(['nueva', 'nueva', 'usada']);
    const baseSpeed = indoor ? 0.45 + rng() * 0.4 : 0.2 + rng() * 0.65;
    const speed = clamp(baseSpeed + (ball === 'nueva' ? 0.06 : -0.07), 0.08, 0.95);
    const court = {
      indoor,
      speed: Math.round(speed * 100) / 100,
      bounce: Math.round((0.22 + rng() * 0.66) * 100) / 100,
      temp: indoor ? rng.int(20, 23) : Math.round(city[1] + rng.gauss() * 3.2),
      wind: indoor ? 0 : Math.max(0, Math.round(city[2] + rng.gauss() * 6)),
      ball
    };
    return {
      id: uid(rng, 't'),
      tier, city: city[0],
      name: TIER_EVENT[tier] + ' de ' + city[0],
      court,
      fee: Math.round(300 * TIER_PRIZE[tier] / 10) * 10
    };
  }

  /* efectos de la pista sobre cada estadística (puntos) */
  function courtDeltas(c) {
    const sp = c.speed - 0.5, bo = c.bounce - 0.5;
    const wind = c.indoor ? 0 : clamp(c.wind / 30, 0, 1.2);
    const heat = c.indoor ? 0 : clamp((c.temp - 22) / 12, -1, 1.5);
    return {
      remate: 24 * sp,
      volea: 18 * sp,
      bandeja: 8 * sp - 10 * wind,
      saque: 14 * sp - 6 * wind,
      defensa: -20 * sp + 16 * bo,
      globo: -10 * sp - 14 * wind + 6 * bo,
      aguante: -12 * Math.max(0, heat) - 6 * Math.max(0, -sp),
      mente: 0
    };
  }
  function courtFatigue(c) {
    const heat = c.indoor ? 0 : clamp((c.temp - 22) / 12, -1, 1.5);
    return clamp(1 + 0.35 * Math.max(0, heat) + 0.25 * (0.5 - c.speed) - (c.indoor ? 0.05 : 0), 0.75, 1.6);
  }

  function traitMods(p, c) {
    const out = {};
    p.traits.forEach((id) => {
      const t = TRAITS[id];
      const m = t && t.mods ? t.mods(c) : null;
      if (m) for (const k in m) out[k] = (out[k] || 0) + m[k];
    });
    return out;
  }
  function traitFatigue(p, c) {
    let f = 1;
    p.traits.forEach((id) => {
      const t = TRAITS[id];
      if (!t) return;
      if (t.fatBase) f *= t.fatBase;
      if (t.fat) f *= t.fat(c);
    });
    return f;
  }
  function traitClutch(p) {
    return p.traits.reduce((s, id) => s + ((TRAITS[id] && TRAITS[id].clutch) || 0), 0);
  }

  const fatigueFactor = (f) => 1 - 0.3 * Math.pow(clamp(f, 0, 100) / 100, 1.1);

  // El efecto de la pista es proporcional a la estadística: un buen rematador gana más
  // con una pista rápida que uno flojo (con stat 55 el efecto es exactamente el delta).
  function effStats(p, c, fatigue) {
    const cd = courtDeltas(c);
    const tm = traitMods(p, c);
    const ff = fatigueFactor(fatigue == null ? p.fatigue : fatigue);
    const out = {};
    STATS.forEach((s) => { out[s] = clamp((p.stats[s] * (1 + cd[s] / 55) + (tm[s] || 0)) * ff, 5, 99); });
    return out;
  }

  /* Aporte individual de un jugador en una pista (para comparar fichajes y alineaciones) */
  function playerRating(p, c, fatigue) {
    const e = effStats(p, c, fatigue);
    const sp = clamp(c.speed - 0.5, -0.45, 0.45);
    const atk = 0.42 * e.remate + 0.34 * e.volea + 0.24 * e.bandeja;
    const def = 0.55 * e.defensa + 0.45 * e.globo;
    return (0.375 + 0.16 * sp) * atk + (0.25 - 0.16 * sp) * def + 0.125 * (e.saque + e.mente + e.aguante);
  }
  function playerFit(p, c) {
    return playerRating(p, c, 0) - playerRating(p, NEUTRAL, 0);
  }

  /* ---------- parejas ---------- */
  const TACTICS = {
    agresiva: { name: 'Agresiva', atk: 1.07, def: 0.94, sigma: 1.6, fat: 1.15, desc: 'Más ataque y más riesgo. Se cansa más.' },
    equilibrada: { name: 'Equilibrada', atk: 1, def: 1, sigma: 0, fat: 1, desc: 'Sin sorpresas.' },
    conservadora: { name: 'Conservadora', atk: 0.95, def: 1.06, sigma: -0.8, fat: 0.88, desc: 'Más defensa y menos errores. Cuida el físico.' }
  };
  const TACTIC_IDS = Object.keys(TACTICS);

  function synergy(pl, extra) {
    let s = 0;
    if (pl[0].side !== pl[1].side) s += 3; else s -= 4;
    const a = styleOf(pl[0]), b = styleOf(pl[1]);
    if ((a === 'ataque' && b === 'defensa') || (a === 'defensa' && b === 'ataque')) s += 2.5;
    else if (a === b && a !== 'mixto') s -= 2;
    return s + (extra || 0);
  }

  /* Composición de una pareja sobre una pista concreta */
  function pairComposite(pl, c, tactic, o) {
    o = o || {};
    const es = pl.map((p, i) => effStats(p, c, o.fatigue ? o.fatigue[i] : undefined));
    const t = TACTICS[tactic || 'equilibrada'];
    const atkI = es.map((e) => 0.42 * e.remate + 0.34 * e.volea + 0.24 * e.bandeja);
    const defI = es.map((e) => 0.55 * e.defensa + 0.45 * e.globo);
    const mix = (arr) => 0.75 * avg(arr) + 0.25 * Math.min(arr[0], arr[1]);
    const atk = mix(atkI) * t.atk;
    const def = mix(defI) * t.def;
    const srv = avg(es.map((e) => e.saque));
    const men = avg(es.map((e) => e.mente));
    const agu = avg(es.map((e) => e.aguante));
    const syn = synergy(pl, o.synBonus);
    // En pista rápida pesa más el ataque; en pista lenta, la defensa.
    const sp = clamp(c.speed - 0.5, -0.45, 0.45);
    const wAtk = 0.375 + 0.16 * sp, wDef = 0.25 - 0.16 * sp;
    const strength = wAtk * atk + wDef * def + 0.125 * srv + 0.125 * men + 0.125 * agu + syn;
    return { atk, def, srv, men, agu, syn, strength };
  }

  /* Valoración "limpia" de una pareja: pista neutra, sin cansancio */
  function pairRating(pl, o) {
    const fresh = pl.map(() => 0);
    return pairComposite(pl, NEUTRAL, 'equilibrada', { fatigue: fresh, synBonus: o && o.synBonus }).strength;
  }
  /* Cuánto mejora o empeora la pareja en esta pista frente a una neutra */
  function pairFit(pl, c, tactic, o) {
    const fat = pl.map((p) => p.fatigue);
    const on = pairComposite(pl, c, tactic, { fatigue: fat, synBonus: o && o.synBonus }).strength;
    const off = pairComposite(pl, NEUTRAL, tactic, { fatigue: fat, synBonus: o && o.synBonus }).strength;
    return on - off;
  }
  function suggestTactic(pl, c, o) {
    let best = 'equilibrada', bv = -1e9;
    TACTIC_IDS.forEach((t) => {
      const v = pairComposite(pl, c, t, { synBonus: o && o.synBonus }).strength - (t === 'agresiva' ? 0.3 : 0);
      if (v > bv) { bv = v; best = t; }
    });
    return best;
  }

  /* ---------- simulación de partidos ---------- */
  const SCALE = 50; // cuanto menor, más decisivo es cada punto de diferencia

  function pointProb(sa, sb) {
    return 0.5 + 0.5 * Math.tanh((sa - sb) / SCALE);
  }

  function simulateMatch(A, B, court, rng) {
    const tA = TACTICS[A.tactic || 'equilibrada'], tB = TACTICS[B.tactic || 'equilibrada'];
    const sigA = 2.4 + tA.sigma, sigB = 2.4 + tB.sigma;
    const formA = rng.gauss() * sigA, formB = rng.gauss() * sigB;
    const fat = [A.players.map((p) => p.fatigue), B.players.map((p) => p.fatigue)];
    const rate = (pair, tact, k) => pair.players.map((p) =>
      0.85 * (1.25 - p.stats.aguante / 160) * courtFatigue(court) * traitFatigue(p, court) * TACTICS[tact || 'equilibrada'].fat * (pair.fatMult || 1)
    );
    const rateA = rate(A, A.tactic), rateB = rate(B, B.tactic);

    const snapshot = {
      a: pairComposite(A.players, court, A.tactic, { fatigue: fat[0], synBonus: A.synBonus }),
      b: pairComposite(B.players, court, B.tactic, { fatigue: fat[1], synBonus: B.synBonus }),
      fitA: pairFit(A.players, court, A.tactic, { synBonus: A.synBonus }),
      fitB: pairFit(B.players, court, B.tactic, { synBonus: B.synBonus }),
      fatA: avg(fat[0]), fatB: avg(fat[1])
    };

    const clutchA = A.players.reduce((s, p) => s + traitClutch(p), 0) / 2;
    const clutchB = B.players.reduce((s, p) => s + traitClutch(p), 0) / 2;

    const sets = [];
    let wa = 0, wb = 0, totalGames = 0;
    let gamesSoFar = 0;

    while (wa < 2 && wb < 2) {
      const setNo = sets.length;
      const momentum = rng.gauss() * 1.2;
      const curFatA = fat[0].map((f, i) => f + rateA[i] * gamesSoFar);
      const curFatB = fat[1].map((f, i) => f + rateB[i] * gamesSoFar);
      const cA = pairComposite(A.players, court, A.tactic, { fatigue: curFatA, synBonus: A.synBonus }).strength;
      const cB = pairComposite(B.players, court, B.tactic, { fatigue: curFatB, synBonus: B.synBonus }).strength;
      const baseA = cA + formA + momentum;
      const baseB = cB + formB - momentum;
      const late = setNo === 2;
      const pNorm = pointProb(baseA + (late ? clutchA : 0), baseB + (late ? clutchB : 0));
      const pTie = pointProb(baseA + clutchA, baseB + clutchB);

      let ga = 0, gb = 0;
      for (;;) {
        if (ga === 6 && gb === 6) {
          let pa = 0, pb = 0;
          while (!((pa >= 7 || pb >= 7) && Math.abs(pa - pb) >= 2)) {
            if (rng() < pTie) pa++; else pb++;
          }
          if (pa > pb) ga = 7; else gb = 7;
          break;
        }
        // punto de oro: gana el juego quien llegue antes a 4 puntos
        let pa = 0, pb = 0;
        while (pa < 4 && pb < 4) { if (rng() < pNorm) pa++; else pb++; }
        if (pa > pb) ga++; else gb++;
        if ((ga >= 6 || gb >= 6) && Math.abs(ga - gb) >= 2) break;
        if (ga === 7 || gb === 7) break;
      }
      sets.push([ga, gb]);
      gamesSoFar += ga + gb;
      totalGames += ga + gb;
      if (ga > gb) wa++; else wb++;
    }

    const winner = wa > wb ? 'A' : 'B';
    const gainA = rateA.map((r) => Math.round(r * totalGames * 10) / 10);
    const gainB = rateB.map((r) => Math.round(r * totalGames * 10) / 10);
    return { sets, winner, totalGames, gainA, gainB, why: explain(snapshot, winner, sets.length), snapshot };
  }

  /* Texto corto que explica por qué ganó el partido */
  function explain(s, winner, nSets) {
    const W = winner === 'A' ? s.a : s.b, L = winner === 'A' ? s.b : s.a;
    const fitW = winner === 'A' ? s.fitA : s.fitB, fitL = winner === 'A' ? s.fitB : s.fitA;
    const fatW = winner === 'A' ? s.fatA : s.fatB, fatL = winner === 'A' ? s.fatB : s.fatA;
    const comps = [
      { k: 'ataque', d: W.atk - L.atk, t: 'Más potencia de ataque.' },
      { k: 'defensa', d: W.def - L.def, t: 'Defensa más sólida.' },
      { k: 'saque', d: W.srv - L.srv, t: 'Mejor saque.' },
      { k: 'mente', d: W.men - L.men, t: 'Más sangre fría en los puntos clave.' },
      { k: 'frescura', d: (fatL - fatW) / 3, t: 'Llegaron más frescos.' },
      { k: 'sinergia', d: W.syn - L.syn, t: 'Mejor entendimiento en pista.' },
      { k: 'pista', d: fitW - fitL, t: 'La pista les favorecía.' }
    ].sort((a, b) => b.d - a.d);
    const out = [];
    if (W.strength + 0.5 < L.strength) out.push('Sorpresa: el favorito sobre el papel perdió.');
    comps.slice(0, 2).forEach((c) => { if (c.d > 1.2) out.push(c.t); });
    if (nSets === 3) out.push('Partido igualado que se decidió en tres sets.');
    if (!out.length) out.push('Partido muy parejo.');
    return out;
  }

  /* ---------- cuadros de torneo ---------- */
  const ROUND_NAMES = ['Octavos', 'Cuartos', 'Semifinales', 'Final'];
  const EXIT_LABEL = ['Octavos', 'Cuartos', 'Semifinales', 'Subcampeones', 'Campeones'];

  function makeAIPair(rng, gender, tier, idx) {
    const f = TIER_FIELD[tier];
    const base = f.mean + rng.gauss() * f.sd;
    const complement = rng.chance(0.6);
    const archs = complement
      ? rng.pick([['atacante', 'defensivo'], ['tecnico', 'fisico'], ['atacante', 'completo'], ['defensivo', 'tecnico'], ['fisico', 'atacante']])
      : [rng.pick(ARCH_IDS), rng.pick(ARCH_IDS)];
    const sides = complement || rng.chance(0.7) ? (rng.chance(0.5) ? ['drive', 'reves'] : ['reves', 'drive']) : ['drive', 'drive'];
    const players = [0, 1].map((i) => makePlayer(rng, {
      gender, arch: archs[i], side: sides[i], ovr: clamp(base + rng.gauss() * 2.5, 28, 92),
      fatigue: rng.int(0, 14), traitChance: 0.4
    }));
    return {
      id: gender + 'ai' + idx, isUser: false, players,
      label: players[0].last + ' / ' + players[1].last,
      tactic: 'equilibrada', synBonus: 0, fatMult: 1
    };
  }

  function makeDraw(rng, o) {
    const size = o.size || 16;
    const pairs = [];
    for (let i = 0; i < size - 1; i++) pairs.push(makeAIPair(rng, o.gender, o.tier, i));
    const up = o.userPair;
    const at = rng.int(0, size - 1);
    pairs.splice(at, 0, up);
    const byId = {};
    pairs.forEach((p) => { byId[p.id] = p; });
    const first = [];
    for (let i = 0; i < size; i += 2) first.push({ a: pairs[i].id, b: pairs[i + 1].id, res: null });
    return { gender: o.gender, size, pairs: byId, order: pairs.map((p) => p.id), rounds: [first], round: 0, done: false, champion: null, exit: {} };
  }

  function aiTactic(rng, pair, court) {
    if (rng.chance(0.2)) return rng.pick(TACTIC_IDS);
    return suggestTactic(pair.players, court);
  }

  /* Juega la ronda actual del cuadro. Devuelve la lista de partidos con resultado. */
  function playRound(draw, court, rng) {
    if (draw.done) return [];
    const matches = draw.rounds[draw.round];
    const winners = [];
    matches.forEach((m) => {
      const A = draw.pairs[m.a], B = draw.pairs[m.b];
      if (!A.isUser) A.tactic = aiTactic(rng, A, court);
      if (!B.isUser) B.tactic = aiTactic(rng, B, court);
      const res = simulateMatch(A, B, court, rng);
      res.tacticA = A.tactic; res.tacticB = B.tactic;
      m.res = res;
      A.players.forEach((p, i) => { p.fatigue = clamp(p.fatigue + res.gainA[i], 0, 100); });
      B.players.forEach((p, i) => { p.fatigue = clamp(p.fatigue + res.gainB[i], 0, 100); });
      const win = res.winner === 'A' ? A : B, lose = res.winner === 'A' ? B : A;
      m.winnerId = win.id;
      draw.exit[lose.id] = draw.round;
      winners.push(win.id);
    });
    if (winners.length === 1) {
      draw.done = true;
      draw.champion = winners[0];
      draw.exit[winners[0]] = 4;
    } else {
      const next = [];
      for (let i = 0; i < winners.length; i += 2) next.push({ a: winners[i], b: winners[i + 1], res: null });
      draw.rounds.push(next);
      draw.round++;
    }
    return matches;
  }

  /* Recompensas */
  const PRIZE_BASE = [200, 500, 1200, 2500, 5000];
  const POINTS_BASE = [10, 25, 50, 90, 150];
  function reward(tier, exitRound) {
    return {
      prize: Math.round(PRIZE_BASE[exitRound] * TIER_PRIZE[tier] / 10) * 10,
      points: Math.round(POINTS_BASE[exitRound] * TIER_POINTS[tier])
    };
  }

  /* ---------- progresión semanal ---------- */
  const GROUPS = {
    tec: ['remate', 'volea', 'bandeja', 'saque'],
    tac: ['defensa', 'globo', 'mente'],
    fis: ['aguante']
  };

  function trainWeek(p, ctx, rng) {
    const before = {};
    STATS.forEach((s) => { before[s] = Math.floor(p.stats[s]); });
    const ageF = p.age <= 22 ? 1 : p.age <= 27 ? 0.8 : p.age <= 31 ? 0.55 : 0.3;
    const fatF = p.fatigue > 70 ? 0.5 : 1;
    STATS.forEach((s) => {
      let bonus = 0.1 * ctx.pistas;
      if (GROUPS.tec.includes(s)) bonus += 0.18 * ctx.tec;
      if (GROUPS.tac.includes(s)) bonus += 0.18 * ctx.tac;
      if (GROUPS.fis.includes(s)) bonus += 0.18 * ctx.fis;
      let g = (s === p.focus ? 0.9 : 0.12) * (1 + bonus) * ageF * fatF * (0.6 + rng() * 0.8) * (ctx.rest ? 1.5 : 1);
      const cap = Math.min(99, p.pot + 8);
      if (p.stats[s] < cap) p.stats[s] = Math.min(cap, p.stats[s] + g);
    });
    const gains = {};
    STATS.forEach((s) => {
      const d = Math.floor(p.stats[s]) - before[s];
      if (d > 0) gains[s] = d;
    });
    return gains;
  }

  function recoverWeek(p, ctx) {
    const rec = 38 + 5 * ctx.recup + (ctx.rest ? 25 : 0) + (p.stats.aguante - 50) / 10;
    const before = p.fatigue;
    p.fatigue = clamp(p.fatigue - rec, 0, 100);
    return before - p.fatigue;
  }

  /* ---------- mercado ---------- */
  function makeMarket(rng, level, avgOvr, count, gender) {
    const out = [];
    for (let i = 0; i < count; i++) {
      const g = gender || (i % 2 === 0 ? 'M' : 'F');
      const ovr = clamp(avgOvr - 6 + rng.int(0, 16) + level * 2.5, 36, 86);
      const p = makePlayer(rng, { gender: g, ovr, traitChance: 0.45 + level * 0.08, age: rng.int(17, 33) });
      if (level >= 3 && rng.chance(0.4)) p.pot = clamp(p.pot + 6, 0, 96);
      out.push(p);
    }
    return out;
  }

  function makeStartingSquad(rng) {
    const specs = [
      { gender: 'M', arch: 'atacante', ovr: 52, side: 'drive', age: 24 },
      { gender: 'M', arch: 'defensivo', ovr: 51, side: 'reves', age: 27 },
      { gender: 'M', arch: 'tecnico', ovr: 47, side: 'reves', age: 19 },
      { gender: 'F', arch: 'atacante', ovr: 52, side: 'reves', age: 23 },
      { gender: 'F', arch: 'defensivo', ovr: 50, side: 'drive', age: 26 },
      { gender: 'F', arch: 'fisico', ovr: 46, side: 'drive', age: 20 }
    ];
    return specs.map((s) => makePlayer(rng, Object.assign({ traitChance: 0.5 }, s)));
  }

  return {
    STATS, STAT_LABEL, STAT_HINT, ARCH, TRAITS, TACTICS, TACTIC_IDS, TIER_NAMES, TIER_SHORT, TIER_AT, TIER_PRIZE, ROUND_NAMES, EXIT_LABEL, NEUTRAL, GROUPS,
    clamp, avg, makeRng,
    overall, overallF, valueOf, wageOf, styleOf, makePlayer, weakest,
    makeTournament, courtDeltas, courtFatigue, speedLabel, bounceLabel, tierForPoints,
    effStats, traitMods, playerFit, pairComposite, pairRating, pairFit, suggestTactic, synergy,
    simulateMatch, makeDraw, makeAIPair, playRound, reward,
    trainWeek, recoverWeek, makeMarket, makeStartingSquad
  };
});
