/* ============================================================
   Padel Manager · aplicación
   Estado del juego, pantallas y acciones. La lógica de partidos
   está en engine.js; los dibujos, en svg.js.
   ============================================================ */
(function () {
  'use strict';
  const PM = window.PM, D = window.PM_DATA, U = window.PM_UI;
  const STATS = PM.STATS, LBL = PM.STAT_LABEL;
  const esc = U.esc;
  const SAVE_KEY = 'padel-manager-v1';
  const $ = (s, r) => (r || document).querySelector(s);

  let S = null; // estado de la partida
  let rng = PM.makeRng(((Date.now() ^ (Math.random() * 4294967296)) >>> 0) || 1);
  const ui = { tab: 'club', squad: 'all', market: 'all', entry: null, drawG: 'M', round: 0, justPlayed: false, sheetFn: null, crest: 0 };

  /* ---------- utilidades ---------- */
  const money = (n) => (n < 0 ? '−' : '') + String(Math.abs(Math.round(n))).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' €';
  const dec = (x, d) => x.toFixed(d == null ? 1 : d).replace('.', ',');
  const signed = (x, d) => (x >= -0.049 && x <= 0.049 ? '0' : (x > 0 ? '+' : '−') + dec(Math.abs(x), d == null ? 1 : d));
  const avg = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

  const ARCH_COLOR = { atacante: '#e8892b', defensivo: '#1e55c6', fisico: '#14a06f', tecnico: '#6b4fd8', completo: '#52617f' };
  const STYLE_COLOR = { ataque: 'var(--amber)', defensa: 'var(--court)', mixto: 'var(--mint)' };

  /* ---------- guardado ---------- */
  function save() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(S, function (k, v) {
        if (k === 'players' && this && this.isUser) return undefined; // las parejas del jugador apuntan a la plantilla
        return v;
      }));
    } catch (e) { /* sin almacenamiento: la partida sigue en memoria */ }
  }
  function load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw);
      if (!s || s.v !== 1) return null;
      if (s.tournament) {
        const byId = {};
        s.players.forEach((p) => { byId[p.id] = p; });
        ['M', 'F'].forEach((g) => {
          Object.keys(s.tournament.draws[g].pairs).forEach((id) => {
            const pr = s.tournament.draws[g].pairs[id];
            if (pr.isUser) pr.players = pr.pids.map((x) => byId[x]);
          });
        });
      }
      return s;
    } catch (e) { return null; }
  }

  /* ---------- reglas del club ---------- */
  const byGender = (g) => S.players.filter((p) => p.gender === g);
  const getP = (id) => S.players.find((p) => p.id === id);
  const tierNow = () => PM.tierForPoints(S.points);
  const boosts = () => ({ synBonus: 0.5 * S.staff.tac, fatMult: 1 - 0.03 * S.staff.fis });
  const squadOvr = () => avg(S.players.map(PM.overall));

  function costs() {
    const wages = S.players.reduce((s, p) => s + PM.wageOf(p), 0);
    const staff = ['tec', 'tac', 'fis'].reduce((s, k) => s + (S.staff[k] ? D.STAFF[k].wages[S.staff[k] - 1] : 0), 0);
    const upkeep = (S.fac.pistas + S.fac.recup + S.fac.cantera) * D.UPKEEP_PER_LEVEL;
    const sponsor = 800 + Math.round((S.points * 1.6) / 10) * 10;
    return { wages, staff, upkeep, sponsor, net: sponsor - wages - staff - upkeep };
  }

  function addLog(text) {
    S.log.unshift({ w: S.week, t: text });
    S.log = S.log.slice(0, 40);
  }

  function makeOffers() {
    const t = tierNow();
    const a = PM.makeTournament(rng, t);
    const b = PM.makeTournament(rng, Math.max(0, t - 1), [a.city]);
    return [a, b];
  }

  function newGame(name, crestIdx) {
    const squad = PM.makeStartingSquad(rng);
    S = {
      v: 1, club: { name: name, crest: D.CRESTS[crestIdx] },
      week: 1, money: 30000, points: 0,
      players: squad, market: [],
      staff: { tec: 0, tac: 0, fis: 0 }, fac: { pistas: 0, recup: 0, cantera: 0 },
      offers: [], tournament: null, log: [], history: []
    };
    S.market = PM.makeMarket(rng, 0, 50, 6);
    S.offers = makeOffers();
    addLog('Nace ' + name + '. Tenéis seis jugadores y muchas ganas.');
    ui.tab = 'club'; ui.entry = null;
    save();
  }

  /* ---------- fin de semana: sueldos, entrenamiento, recuperación ---------- */
  function endWeek(rested) {
    const c = costs();
    const sum = { week: S.week, rested: !!rested, sponsor: c.sponsor, wages: c.wages, staff: c.staff, upkeep: c.upkeep, gains: [], recovered: 0 };
    S.money += c.net;
    const ctx = { tec: S.staff.tec, tac: S.staff.tac, fis: S.staff.fis, pistas: S.fac.pistas, recup: S.fac.recup, rest: !!rested };
    let rec = 0;
    S.players.forEach((p) => {
      const g = PM.trainWeek(p, ctx, rng);
      if (Object.keys(g).length) sum.gains.push({ name: p.name, g: g });
      rec += PM.recoverWeek(p, ctx);
    });
    sum.recovered = Math.round(rec / S.players.length);
    sum.gains.forEach((x) => {
      addLog(x.name + ' mejora: ' + Object.keys(x.g).map((k) => LBL[k].toLowerCase() + ' +' + x.g[k]).join(', ') + '.');
    });
    // el mercado se renueva a medias
    const keep = S.market.filter(() => rng() < 0.5);
    const want = 6 + Math.floor(S.fac.cantera / 2);
    const fresh = PM.makeMarket(rng, S.fac.cantera, Math.max(44, Math.min(72, squadOvr())), Math.max(2, want - keep.length));
    S.market = keep.concat(fresh).slice(0, 10);
    S.week++;
    S.offers = makeOffers();
    ui.entry = null;
    save();
    return sum;
  }

  /* ---------- torneo ---------- */
  function autoPick(g, court) {
    const list = byGender(g);
    let best = null, bv = -1e9;
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const v = PM.pairComposite([list[i], list[j]], court, 'equilibrada', boosts()).strength;
        if (v > bv) { bv = v; best = [list[i].id, list[j].id]; }
      }
    }
    return best || [];
  }
  const pairPlayers = (g) => ui.entry[g].map(getP);
  const recTactic = (g, court) => PM.suggestTactic(pairPlayers(g), court, boosts());

  function startTournament() {
    const e = ui.entry, t = S.offers[e.offer];
    const total = t.fee * 2;
    if (S.money < total) return toast('Te faltan ' + money(total - S.money) + ' para la inscripción.');
    if (e.M.length < 2 || e.F.length < 2) return toast('Elige dos jugadores en cada pareja.');
    S.money -= total;
    const mk = (g) => {
      const pl = e[g].map(getP);
      return Object.assign({
        id: 'USER_' + g, isUser: true, pids: e[g].slice(), players: pl,
        label: pl[0].last + ' / ' + pl[1].last, tactic: e['t' + g]
      }, boosts());
    };
    const draws = {};
    ['M', 'F'].forEach((g) => { draws[g] = PM.makeDraw(rng, { gender: g, tier: t.tier, userPair: mk(g) }); });
    S.tournament = { t: t, draws: draws, status: 'playing', fee: total, result: null };
    ui.entry = null; ui.drawG = 'M'; ui.round = 0; ui.justPlayed = false;
    addLog('Inscribes dos parejas en el ' + t.name + '.');
    save();
    render({ top: true });
  }

  function playRound() {
    const T = S.tournament;
    if (!T || T.status !== 'playing') return;
    ['M', 'F'].forEach((g) => Object.assign(T.draws[g].pairs['USER_' + g], boosts()));
    ui.round = T.draws.M.round;
    ['M', 'F'].forEach((g) => PM.playRound(T.draws[g], T.t.court, rng));
    ui.justPlayed = true;
    if (T.draws.M.done && T.draws.F.done) finishTournament();
    save();
    render();
  }

  function simToEnd() {
    const T = S.tournament;
    if (!T || T.status !== 'playing') return;
    while (!(T.draws.M.done && T.draws.F.done)) {
      ui.round = T.draws.M.round;
      ['M', 'F'].forEach((g) => PM.playRound(T.draws[g], T.t.court, rng));
    }
    finishTournament();
    ui.justPlayed = false;
    save();
    render();
  }

  function finishTournament() {
    const T = S.tournament, t = T.t;
    const before = tierNow();
    const res = {};
    let prize = 0, pts = 0;
    ['M', 'F'].forEach((g) => {
      const ex = T.draws[g].exit['USER_' + g];
      const r = PM.reward(t.tier, ex);
      res[g] = { exit: ex, prize: r.prize, points: r.points };
      prize += r.prize; pts += r.points;
    });
    S.money += prize; S.points += pts;
    T.result = { res: res, prize: prize, points: pts, net: prize - T.fee };
    T.status = 'done';
    S.history.unshift({ w: S.week, name: t.name, tier: t.tier, M: res.M.exit, F: res.F.exit, prize: prize, points: pts });
    S.history = S.history.slice(0, 12);
    addLog(t.name + ': ' + PM.EXIT_LABEL[res.M.exit].toLowerCase() + ' en masculino y ' + PM.EXIT_LABEL[res.F.exit].toLowerCase() + ' en femenino. ' + money(prize) + ' y ' + pts + ' puntos.');
    const after = tierNow();
    if (after > before) {
      T.result.promoted = after;
      addLog('Ascenso al ' + PM.TIER_NAMES[after] + '. Los rivales serán más duros.');
    }
  }

  /* ---------- avisos y hojas ---------- */
  let toastTimer = 0;
  function toast(msg) {
    const el = $('#toast');
    el.textContent = msg; el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
  }
  function openSheet(fn) {
    ui.sheetFn = fn;
    const r = $('#sheet-root');
    r.innerHTML = '<div class="sheet-back" data-a="close"></div><div class="sheet" role="dialog" aria-modal="true"><button class="grab" data-a="close" aria-label="Cerrar"></button><div class="sheet-body">' + fn() + '</div></div>';
    requestAnimationFrame(() => requestAnimationFrame(() => r.classList.add('open')));
  }
  function refreshSheet() {
    if (!ui.sheetFn) return;
    const sh = $('.sheet');
    if (!sh) return;
    const st = sh.scrollTop;
    $('.sheet-body', sh).innerHTML = ui.sheetFn();
    sh.scrollTop = st;
  }
  function closeSheet() {
    const r = $('#sheet-root');
    r.classList.remove('open');
    ui.sheetFn = null;
    setTimeout(() => { if (!ui.sheetFn) r.innerHTML = ''; }, 300);
  }
  function confirmSheet(o) {
    openSheet(() =>
      '<h2>' + esc(o.title) + '</h2><p class="muted" style="margin-top:8px">' + o.text + '</p>' +
      '<div class="actions"><button class="btn block ' + (o.danger ? 'dark' : '') + '" data-a="' + o.action + '" ' + (o.data || '') + '>' + esc(o.ok) + '</button>' +
      '<button class="btn ghost block" data-a="close">Cancelar</button></div>');
  }

  /* ---------- piezas de pantalla ---------- */
  function initials(p) { return (p.first.charAt(0) + p.last.charAt(0)).toUpperCase(); }

  function ticket(p, o) {
    o = o || {};
    const style = PM.styleOf(p);
    const fit = o.court ? PM.playerFit(p, o.court) : null;
    const right = fit != null
      ? '<span class="delta ' + (fit >= 0.05 ? 'up' : fit <= -0.05 ? 'down' : '') + '">' + signed(fit) + ' pista</span>'
      : (o.extra || 'Media');
    const act = o.action ? ' data-a="' + o.action + '" data-id="' + p.id + '" role="button" tabindex="0"' + (o.pressed != null ? ' aria-pressed="' + o.pressed + '"' : '') : '';
    return '<div class="ticket' + (o.sel ? ' sel' : '') + (o.dim ? ' dim' : '') + '" style="--st:' + STYLE_COLOR[style] + '"' + act + '>' +
      '<span class="avatar" style="--av:' + ARCH_COLOR[p.arch] + '">' + esc(initials(p)) + '</span>' +
      '<span><span class="nm">' + esc(p.name) + '</span>' +
      '<span class="sub"><span>' + p.age + ' años, ' + PM.ARCH[p.arch].name.toLowerCase() + '</span><span>' + U.sideIcon(p.side) + ' ' + (p.side === 'drive' ? 'drive' : 'revés') + '</span></span></span>' +
      '<span class="ovr"><b class="num">' + PM.overall(p) + '</b><span>' + right + '</span></span>' +
      (o.nofat ? '' : '<span class="fatrow">' + U.fatBar(p.fatigue) + '<span>Cansancio ' + Math.round(p.fatigue) + '%</span>' +
      (o.info ? '<span class="link" data-a="player-court" data-id="' + p.id + '" role="button" tabindex="0">Ver ficha</span>' : '') + '</span>') + '</div>';
  }

  function condChips(c, light) {
    const cl = 'chip' + (light ? ' light' : '');
    const items = [
      ['bolt', 'Pista ' + PM.speedLabel(c.speed).toLowerCase()],
      ['glass', PM.bounceLabel(c.bounce)],
      c.indoor ? ['roof', 'Cubierta'] : ['therm', c.temp + 'º'],
      !c.indoor && c.wind >= 6 ? ['wind', c.wind + ' km/h'] : null,
      ['ball', c.ball === 'nueva' ? 'Bolas nuevas' : 'Bolas usadas']
    ].filter(Boolean);
    return '<div class="chips">' + items.map((x) => '<span class="' + cl + '">' + U.icon(x[0]) + esc(x[1]) + '</span>').join('') + '</div>';
  }

  function courtNotes(c) {
    const n = [];
    if (c.speed >= 0.64) n.push(['bolt', 'Pista rápida', 'Favorece remate, volea y saque. En esta pista pesa más el ataque.']);
    else if (c.speed <= 0.36) n.push(['bolt', 'Pista lenta', 'La bola pierde fuerza. Favorece defensa y globo, y se juega a ritmo largo.']);
    else n.push(['bolt', 'Pista media', 'Sin grandes sesgos de estilo. Gana el más completo.']);
    if (c.bounce >= 0.65) n.push(['glass', 'Cristal vivo', 'Las salidas de pared van largas. Se lucen los que defienden con el cristal.']);
    else if (c.bounce <= 0.4) n.push(['glass', 'Rebote bajo', 'La bola muere pronto en la pared. Cuesta más defender atrás.']);
    if (c.indoor) n.push(['roof', 'Bajo techo', 'Sin viento ni calor. Temperatura estable de ' + c.temp + 'º.']);
    else if (c.temp >= 28) n.push(['therm', 'Calor de ' + c.temp + 'º', 'El cansancio sube un ' + Math.round((PM.courtFatigue(c) - 1) * 100) + '%. Los jugadores con poco aguante lo notarán.']);
    else if (c.temp <= 14) n.push(['therm', 'Frío de ' + c.temp + 'º', 'La bola va más pesada. El cansancio es algo menor.']);
    if (!c.indoor && c.wind >= 12) n.push(['wind', 'Viento de ' + c.wind + ' km/h', 'Globos y bandejas pierden precisión. Los marineros no lo sufren.']);
    n.push(['ball', c.ball === 'nueva' ? 'Bolas nuevas' : 'Bolas usadas', c.ball === 'nueva' ? 'La pelota vuela más y bota con viveza.' : 'La pelota pesa y el juego se frena.']);
    return '<div class="notes">' + n.map((x) => '<div class="note">' + U.icon(x[0]) + '<div><b>' + esc(x[1]) + '</b><span>' + esc(x[2]) + '</span></div></div>').join('') + '</div>';
  }

  function levelPips(l) {
    let s = '<div class="pips" role="img" aria-label="Nivel ' + l + ' de 5">';
    for (let i = 1; i <= 5; i++) s += '<i class="' + (i <= l ? 'on' : '') + '"></i>';
    return s + '</div>';
  }

  /* ---------- pantalla de bienvenida ---------- */
  function renderWelcome() {
    $('#top').hidden = true; $('#nav').hidden = true;
    const v = $('#view');
    v.classList.add('no-pad');
    v.innerHTML =
      '<div class="welcome">' + U.courtLines('lines') +
      '<h1>Padel<br>Manager</h1>' +
      '<p class="lead">Dirige tu club, entrena a tus parejas y gana el circuito. La pista decide más de lo que parece.</p>' +
      '<ul><li>Cada semana eliges torneo y presentas una pareja masculina y otra femenina.</li>' +
      '<li>Cada pista es distinta: rápida o lenta, cubierta o con calor y viento.</li>' +
      '<li>Mejora tu academia y ficha técnicos para que tus jugadores crezcan.</li></ul>' +
      '<form id="newgame" autocomplete="off"><label for="clubname">Nombre de tu club</label>' +
      '<input id="clubname" name="club" type="text" maxlength="22" placeholder="Club Pádel Costa" value="">' +
      '<div class="crest-pick" role="group" aria-label="Color del escudo">' +
      D.CRESTS.map((c, i) => '<button type="button" data-a="crest" data-i="' + i + '" aria-pressed="' + (ui.crest === i) + '" aria-label="Escudo ' + c.id + '">' + U.crest({ name: 'C', crest: c }, 46) + '</button>').join('') +
      '</div><button class="btn block" type="submit">Empezar la temporada</button></form></div>';
  }

  /* ---------- barra superior e inferior ---------- */
  function renderTop() {
    const el = $('#top');
    el.hidden = false;
    el.innerHTML = U.crest(S.club, 36) +
      '<div class="club"><b>' + esc(S.club.name) + '</b><span>' + PM.TIER_NAMES[tierNow()] + ', ' + S.points + ' puntos</span></div>' +
      '<div class="cash"><b class="num">' + money(S.money) + '</b><span>En caja</span></div>';
  }
  function renderNav() {
    const el = $('#nav');
    el.hidden = false;
    const tabs = [['club', 'Club', 'club'], ['squad', 'Plantilla', 'players'], ['torneo', 'Torneo', 'trophy'], ['academia', 'Academia', 'academy'], ['mercado', 'Mercado', 'market']];
    const attention = S.tournament && S.tournament.status !== 'done' ? true : S.tournament && S.tournament.status === 'done';
    el.innerHTML = tabs.map((t) => {
      const cur = ui.tab === t[0] ? ' aria-current="page"' : '';
      if (t[0] === 'torneo') {
        return '<button class="tab main" data-a="tab" data-t="torneo"' + cur + '><span class="ball">' + U.icon('trophy') + '</span><span>Torneo</span>' + (attention && ui.tab !== 'torneo' ? '<i class="dot"></i>' : '') + '</button>';
      }
      return '<button class="tab" data-a="tab" data-t="' + t[0] + '"' + cur + '>' + U.icon(t[2]) + '<span>' + t[1] + '</span></button>';
    }).join('');
  }

  /* ---------- club ---------- */
  function viewClub() {
    const t = tierNow(), next = PM.TIER_AT[t + 1];
    const prog = next ? Math.min(100, ((S.points - PM.TIER_AT[t]) / (next - PM.TIER_AT[t])) * 100) : 100;
    const c = costs();
    const fat = avg(S.players.map((p) => p.fatigue));
    let h = '<div class="hero">' + U.courtLines('lines') +
      '<div class="wk num">Semana ' + S.week + '</div><div class="tier">' + PM.TIER_NAMES[t] + '</div>' +
      '<div class="progress"><div class="bar"><i style="width:' + prog.toFixed(0) + '%"></i></div><div class="lbl"><span>' + S.points + ' puntos</span><span>' +
      (next ? 'Faltan ' + (next - S.points) + ' para el ' + PM.TIER_NAMES[t + 1] : 'Categoría máxima') + '</span></div></div></div>';
    h += '<div class="kpis"><div class="kpi"><b class="num">' + Math.round(squadOvr()) + '</b><span>Nivel medio</span></div>' +
      '<div class="kpi' + (fat >= 50 ? ' warn' : '') + '"><b class="num">' + Math.round(fat) + '%</b><span>Cansancio medio</span></div>' +
      '<div class="kpi' + (c.net < 0 ? ' warn' : '') + '"><b class="num">' + (c.net >= 0 ? '+' : '') + money(c.net).replace(' €', '') + '</b><span>Balance semanal</span></div></div>';

    if (S.tournament) {
      const T = S.tournament;
      h += '<div class="sec">Torneo en curso</div><div class="court-card"><div class="art" style="grid-template-columns:1fr"><div><h3>' + esc(T.t.name) + '</h3><div class="meta">' +
        (T.status === 'done' ? 'Terminado, falta cerrarlo' : 'Próxima ronda: ' + PM.ROUND_NAMES[T.draws.M.round]) + '</div></div></div>' +
        '<div class="foot"><small>Tus dos parejas siguen compitiendo.</small><button class="btn sm" data-a="tab" data-t="torneo">Continuar</button></div></div>';
    } else {
      h += '<div class="sec">Esta semana</div><div class="list">' + S.offers.map((t, i) =>
        '<button class="ticket" style="--st:var(--court);grid-template-columns:1fr auto" data-a="goto-offer" data-i="' + i + '"><span><span class="nm">' + esc(t.name) + '</span>' +
        '<span class="sub">' + PM.TIER_NAMES[t.tier] + ', ' + PM.speedLabel(t.court.speed).toLowerCase() + (t.court.indoor ? ', cubierta' : ', ' + t.court.temp + 'º') + '</span></span>' +
        '<span class="ovr"><b class="num" style="font-size:22px">' + money(t.fee * 2).replace(' €', '') + '</b><span>Inscripción</span></span></button>').join('') + '</div>';
    }

    h += '<div class="sec">Noticias</div><ul class="news">' +
      S.log.slice(0, 7).map((l) => '<li><span class="w">Sem. ' + l.w + '</span><span>' + esc(l.t) + '</span></li>').join('') + '</ul>';
    h += '<div class="foot-links"><button class="link" data-a="reset-ask">Empezar una partida nueva</button></div>';
    return h;
  }

  /* ---------- plantilla ---------- */
  function viewSquad() {
    const c = costs();
    let list = S.players.slice().sort((a, b) => (a.gender === b.gender ? PM.overall(b) - PM.overall(a) : a.gender === 'M' ? -1 : 1));
    if (ui.squad !== 'all') list = list.filter((p) => p.gender === ui.squad);
    let h = '<div class="summary-strip"><div><b class="num">' + S.players.length + '/' + D.MAX_SQUAD + '</b><span>Plazas</span></div>' +
      '<div><b class="num">' + money(c.wages).replace(' €', '') + '</b><span>Sueldos por semana</span></div>' +
      '<div><b class="num">' + byGender('M').length + ' / ' + byGender('F').length + '</b><span>Hombres / mujeres</span></div></div>';
    h += seg('squad', [['all', 'Todos'], ['M', 'Masculino'], ['F', 'Femenino']], ui.squad);
    h += '<div class="list" style="margin-top:14px">' + list.map((p) => ticket(p, { action: 'player' })).join('') + '</div>';
    h += '<p class="muted small" style="margin-top:14px">Para competir necesitas al menos dos hombres y dos mujeres. Toca a un jugador para ver su ficha y elegir su entrenamiento.</p>';
    return h;
  }

  function seg(key, opts, cur) {
    return '<div class="seg" role="group">' + opts.map((o) => '<button data-a="seg" data-k="' + key + '" data-v="' + o[0] + '" aria-pressed="' + (cur === o[0]) + '">' + o[1] + '</button>').join('') + '</div>';
  }

  function playerSheet(p, o) {
    o = o || {};
    const eff = o.court ? PM.effStats(p, o.court, 0) : null;
    let h = '<div class="head"><span class="avatar" style="--av:' + ARCH_COLOR[p.arch] + '">' + esc(initials(p)) + '</span>' +
      '<div><h2>' + esc(p.name) + '</h2><div class="muted small">' + (p.gender === 'M' ? 'Masculino' : 'Femenino') + ', ' + p.age + ' años</div></div>' +
      '<div class="ovr"><b class="num">' + PM.overall(p) + '</b><span>Nivel</span></div></div>';
    h += U.radarSvg(p, o.court);
    if (o.court) h += '<p class="muted small" style="text-align:center">La línea discontinua muestra cómo rinde en esta pista, con el jugador descansado.</p>';
    h += '<div class="facts"><div><b>' + PM.ARCH[p.arch].name + '</b><span>Perfil</span></div><div><b>' + (p.side === 'drive' ? 'Drive' : 'Revés') + '</b><span>' + (p.side === 'drive' ? 'Derecha' : 'Izquierda') + '</span></div><div><b class="num">' + p.pot + '</b><span>Techo estimado</span></div></div>';
    h += '<div class="sec">Estadísticas</div><div class="stats">' + STATS.map((k) => {
      const v = p.stats[k], d = eff ? eff[k] - v : null;
      return '<div class="stat' + (!o.market && !o.court && p.focus === k ? ' focus' : '') + '"><span>' + LBL[k] + '</span><span class="bar"><i style="width:' + Math.max(3, ((v - 20) / 80) * 100).toFixed(0) + '%"></i></span>' +
        '<span class="v">' + Math.round(v) + (d != null ? '<small class="delta ' + (d >= 0.5 ? 'up' : d <= -0.5 ? 'down' : '') + '">' + signed(d, 0) + '</small>' : '') + '</span></div>';
    }).join('') + '</div>';
    h += '<div class="sec">Rasgos</div>';
    h += p.traits.length ? p.traits.map((id) => {
      const t = PM.TRAITS[id];
      return '<div class="trait"><span class="tag ' + (t.good ? 'good' : 'bad') + '">' + esc(t.name) + '</span><span>' + esc(t.desc) + '</span></div>';
    }).join('') : '<p class="muted small">Sin rasgos especiales. Rinde igual en cualquier pista.</p>';

    if (!o.market && !o.court) {
      h += '<div class="sec">Entrenamiento de la semana</div><p class="muted small">Progresa más rápido en la estadística elegida.</p><div class="focus-pick">' +
        STATS.map((k) => '<button data-a="focus" data-id="' + p.id + '" data-k="' + k + '" aria-pressed="' + (p.focus === k) + '">' + LBL[k] + '</button>').join('') + '</div>';
    }
    h += '<div class="facts"><div><b class="num">' + money(PM.wageOf(p)).replace(' €', '') + '</b><span>Sueldo semanal</span></div><div><b class="num">' + money(PM.valueOf(p)).replace(' €', '') + '</b><span>Valor</span></div><div><b class="num">' + Math.round(p.fatigue) + '%</b><span>Cansancio</span></div></div>';
    if (o.market) {
      const price = PM.valueOf(p);
      h += '<div class="actions"><button class="btn block" data-a="sign" data-id="' + p.id + '"' + (S.money < price || S.players.length >= D.MAX_SQUAD ? ' disabled' : '') + '>Fichar por ' + money(price) + '</button>' +
        (S.players.length >= D.MAX_SQUAD ? '<p class="muted small" style="text-align:center">Plantilla completa. Vende a alguien para hacer sitio.</p>' : S.money < price ? '<p class="muted small" style="text-align:center">Te faltan ' + money(price - S.money) + '.</p>' : '') + '</div>';
    } else if (!o.court) {
      h += '<div class="actions"><button class="btn danger block" data-a="sell-ask" data-id="' + p.id + '">Vender por ' + money(Math.round(PM.valueOf(p) * 0.65)) + '</button></div>';
    }
    return h;
  }

  /* ---------- academia ---------- */
  function viewAcademia() {
    const c = costs();
    let h = '<div class="summary-strip"><div><b class="num">' + money(c.sponsor).replace(' €', '') + '</b><span>Patrocinio semanal</span></div>' +
      '<div><b class="num">' + money(c.wages + c.staff + c.upkeep).replace(' €', '') + '</b><span>Gastos semanales</span></div>' +
      '<div><b class="num" style="color:' + (c.net < 0 ? 'var(--clay)' : 'var(--ball)') + '">' + (c.net >= 0 ? '+' : '') + money(c.net).replace(' €', '') + '</b><span>Balance</span></div></div>';
    h += '<div class="sec">Cuerpo técnico</div><div class="list">';
    ['tec', 'tac', 'fis'].forEach((k) => {
      const d = D.STAFF[k], l = S.staff[k];
      h += '<div class="row-card"><div class="hd"><div><h3>' + d.name + '</h3><p>' + d.blurb + '</p></div>' + levelPips(l) + '</div>';
      if (l > 0) {
        const co = d.coaches[l - 1];
        h += '<div class="coach"><span class="avatar">' + esc(co[0].split(' ').map((x) => x.charAt(0)).join('').slice(0, 2)) + '</span><div><b>' + esc(co[0]) + '</b><span>' + esc(co[1]) + ' Cobra ' + money(d.wages[l - 1]) + ' por semana.</span></div></div>';
      } else h += '<p class="muted small">Todavía no tienes a nadie en este puesto.</p>';
      if (l < 5) {
        const nx = d.coaches[l], cost = d.costs[l];
        h += '<div class="next"><div><b>' + esc(nx[0]) + '</b><small>' + d.perLevel + '. Sueldo ' + money(d.wages[l]) + '/sem.</small></div><button class="btn sm block" data-a="upgrade-staff" data-k="' + k + '"' + (S.money < cost ? ' disabled' : '') + '>Fichar ' + money(cost) + '</button></div>';
      } else h += '<p class="small" style="font-weight:700;color:#0b6b49">Tienes al mejor del circuito.</p>';
      h += '</div>';
    });
    h += '</div><div class="sec">Instalaciones</div><div class="list">';
    ['pistas', 'recup', 'cantera'].forEach((k) => {
      const d = D.FAC[k], l = S.fac[k];
      h += '<div class="row-card"><div class="hd"><div><h3>' + d.name + '</h3><p>' + d.blurb + '</p></div>' + levelPips(l) + '</div>';
      if (l < 5) {
        h += '<div class="next"><div><b>Nivel ' + (l + 1) + '</b><small>' + d.perLevel + '. Mantenimiento ' + money(D.UPKEEP_PER_LEVEL) + '/sem.</small></div><button class="btn sm block" data-a="upgrade-fac" data-k="' + k + '"' + (S.money < d.costs[l] ? ' disabled' : '') + '>Mejorar ' + money(d.costs[l]) + '</button></div>';
      } else h += '<p class="small" style="font-weight:700;color:#0b6b49">Instalación al máximo.</p>';
      h += '</div>';
    });
    return h + '</div>';
  }

  /* ---------- mercado ---------- */
  function viewMercado() {
    let list = S.market.slice().sort((a, b) => PM.overall(b) - PM.overall(a));
    if (ui.market !== 'all') list = list.filter((p) => p.gender === ui.market);
    let h = '<div class="summary-strip"><div><b class="num">' + S.players.length + '/' + D.MAX_SQUAD + '</b><span>Plazas ocupadas</span></div>' +
      '<div><b class="num">' + S.market.length + '</b><span>Jugadores libres</span></div><div><b class="num">' + S.fac.cantera + '/5</b><span>Cantera y ojeo</span></div></div>';
    h += seg('market', [['all', 'Todos'], ['M', 'Masculino'], ['F', 'Femenino']], ui.market);
    h += '<div class="list" style="margin-top:14px">' + (list.length ? list.map((p) => ticket(p, { action: 'market-player', nofat: true, extra: '<span class="price num">' + money(PM.valueOf(p)) + '</span>' })).join('') : '<div class="empty">No hay jugadores de este tipo ahora mismo.</div>') + '</div>';
    h += '<p class="muted small" style="margin-top:14px">El mercado se renueva cada semana. Mejora la cantera para ver más y mejores jugadores.</p>';
    return h;
  }

  /* ---------- torneo: calendario ---------- */
  function viewTorneo() {
    if (S.tournament) return viewTournament();
    if (ui.entry) return viewEntry();
    let h = '<div class="sec">Calendario, semana ' + S.week + '</div><div class="list">';
    h += S.offers.map((t, i) => {
      const win = PM.reward(t.tier, 4).prize;
      return '<article class="court-card"><div class="art"><div style="width:100px">' + U.courtSvg(t.court) + '</div><div><h3>' + esc(t.name) + '</h3><div class="meta">' +
        PM.TIER_NAMES[t.tier] + '</div>' + condChips(t.court) + '</div></div>' +
        '<div class="foot"><small>Inscripción ' + money(t.fee) + ' por pareja<br>Premio al campeón ' + money(win) + '</small><button class="btn sm" data-a="pick-offer" data-i="' + i + '">Preparar</button></div></article>';
    }).join('');
    h += '</div><div class="sec">O descansar</div><div class="rest-card"><div><b>Semana de descanso</b><span>Toda la plantilla recupera 25 puntos de cansancio extra y entrena un 50% más. No pagas inscripción ni cobras premios.</span></div><button class="btn sm ghost" data-a="rest-ask">Descansar</button></div>';
    if (S.history.length) {
      h += '<div class="sec">Últimos torneos</div><ul class="news">' + S.history.slice(0, 4).map((x) =>
        '<li><span class="w">Sem. ' + x.w + '</span><span><b>' + esc(x.name) + '</b><br>Masculino: ' + PM.EXIT_LABEL[x.M].toLowerCase() + '. Femenino: ' + PM.EXIT_LABEL[x.F].toLowerCase() + '. <span class="pos">' + money(x.prize) + '</span></span></li>').join('') + '</ul>';
    }
    return h;
  }

  /* ---------- torneo: preparar parejas ---------- */
  function pairBox(g, c) {
    const e = ui.entry;
    const label = g === 'M' ? 'Pareja masculina' : 'Pareja femenina';
    const list = byGender(g).sort((a, b) => PM.playerFit(b, c) + PM.overallF(b) - (PM.playerFit(a, c) + PM.overallF(a)));
    let h = '<div class="sec">' + label + '</div><div class="pairbox"><div class="hd"><b>Elige dos jugadores</b><button class="link" data-a="autopick" data-g="' + g + '">Elegir la mejor pareja</button></div><div class="list">';
    h += list.map((p) => ticket(p, { action: 'pick', court: c, sel: e[g].includes(p.id), info: true, pressed: e[g].includes(p.id), dim: e[g].length === 2 && !e[g].includes(p.id) })).join('');
    h += '</div>';
    if (e[g].length === 2) {
      const pl = pairPlayers(g), b = boosts(), tac = e['t' + g];
      const now = PM.pairComposite(pl, c, tac, b).strength;
      const fit = PM.pairFit(pl, c, tac, b), syn = PM.synergy(pl, b.synBonus);
      const rec = recTactic(g, c);
      h += '<div class="pairsum"><div><b class="num">' + dec(now, 0) + '</b><span>Nivel hoy</span></div>' +
        '<div><b class="num delta ' + (fit >= 0.05 ? 'up' : fit <= -0.05 ? 'down' : '') + '">' + signed(fit) + '</b><span>Encaje</span></div>' +
        '<div><b class="num delta ' + (syn >= 0.05 ? 'up' : syn <= -0.05 ? 'down' : '') + '">' + signed(syn) + '</b><span>Sinergia</span></div>' +
        '<div><b class="num">' + Math.round(avg(pl.map((p) => p.fatigue))) + '%</b><span>Cansancio</span></div></div>';
      h += tacticPicker(g, tac, rec);
    } else {
      h += '<p class="muted small" style="margin-top:10px">Selecciona dos jugadores para ver su nivel en esta pista.</p>';
    }
    return h + '</div>';
  }

  function tacticPicker(g, cur, rec) {
    return '<div class="tactics">' + PM.TACTIC_IDS.map((id) =>
      '<button data-a="tactic" data-g="' + g + '" data-t="' + id + '" aria-pressed="' + (cur === id) + '"><b>' + PM.TACTICS[id].name + '</b><span class="' + (rec === id ? 'rec' : '') + '">' + (rec === id ? 'Recomendada' : '&nbsp;') + '</span></button>').join('') + '</div>' +
      '<p class="tactic-desc">' + PM.TACTICS[cur].desc + '</p>';
  }

  function viewEntry() {
    const e = ui.entry, t = S.offers[e.offer], c = t.court;
    const total = t.fee * 2;
    const ready = e.M.length === 2 && e.F.length === 2;
    let h = '<button class="link" data-a="entry-back" style="display:inline-flex;align-items:center;gap:4px">' + U.icon('back').replace('<svg', '<svg width="18" height="18" style="fill:none;stroke:currentColor;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round"') + 'Calendario</button>';
    h += '<div class="court-card" style="margin-top:6px"><div class="art big"><div style="width:150px">' + U.courtSvg(c) + '</div><div style="text-align:center"><h3>' + esc(t.name) + '</h3><div class="meta">' + PM.TIER_NAMES[t.tier] + '</div></div></div><div style="padding:0 14px 14px">' + condChips(c) + '</div></div>';
    h += courtNotes(c);
    h += pairBox('M', c) + pairBox('F', c);
    h += '<div class="cta-bar"><button class="btn block" data-a="enter"' + (!ready || S.money < total ? ' disabled' : '') + '>' +
      (!ready ? 'Elige las dos parejas' : S.money < total ? 'Te faltan ' + money(total - S.money) : 'Inscribir a las dos parejas, ' + money(total)) + '</button></div>';
    return h;
  }

  /* ---------- torneo: en juego ---------- */
  function exitText(ex, done) {
    return PM.EXIT_LABEL[ex];
  }

  function viewTournament() {
    const T = S.tournament, t = T.t, done = T.status === 'done';
    const dM = T.draws.M, dF = T.draws.F;
    const curRound = done ? 3 : dM.round;
    let h = '<div class="court-card"><div class="art" style="grid-template-columns:90px 1fr"><div>' + U.courtSvg(t.court) + '</div><div><h3>' + esc(t.name) + '</h3><div class="meta">' + PM.TIER_NAMES[t.tier] + '</div>' + condChips(t.court) + '</div></div></div>';

    if (done) h += resultCard(T);
    else {
      h += '<div class="sec">Tus parejas</div><div class="mypairs">';
      ['M', 'F'].forEach((g) => {
        const d = T.draws[g], pr = d.pairs['USER_' + g];
        const eliminated = d.exit[pr.id] != null && d.exit[pr.id] < d.round;
        const st = eliminated ? '<span class="st out">Eliminadas en ' + PM.ROUND_NAMES[d.exit[pr.id]].toLowerCase() + '</span>' : '<span class="st ok">Siguen vivas</span>';
        h += '<div class="mp"><div class="top"><span><span class="tag">' + (g === 'M' ? 'Masculina' : 'Femenina') + '</span><b>' + esc(pr.label) + '</b></span>' + st + '</div><div class="pl">' +
          pr.players.map((p) => '<div><b>' + esc(p.name) + '</b>' + U.fatBar(p.fatigue) + 'Cansancio ' + Math.round(p.fatigue) + '%</div>').join('') + '</div>';
        if (!eliminated) h += tacticPicker(g, pr.tactic, PM.suggestTactic(pr.players, t.court, boosts()));
        h += '</div>';
      });
      h += '</div>';
      const bothOut = ['M', 'F'].every((g) => { const d = T.draws[g]; const x = d.exit['USER_' + g]; return x != null && x < d.round; });
      h += '<div style="margin-top:18px;display:grid;gap:10px"><button class="btn block" data-a="play-round">Jugar ' + PM.ROUND_NAMES[dM.round].toLowerCase() + '</button>' +
        (bothOut ? '<button class="btn ghost block" data-a="sim-end">Simular hasta el final</button>' : '') + '</div>';
    }

    // cuadro
    h += '<div class="sec">Cuadro</div>' + seg('drawG', [['M', 'Masculino'], ['F', 'Femenino']], ui.drawG);
    const d = T.draws[ui.drawG];
    const showRound = Math.min(ui.round, d.rounds.length - 1);
    h += '<div class="rounds" role="group">' + d.rounds.map((r, i) =>
      '<button data-a="round" data-i="' + i + '" aria-pressed="' + (showRound === i) + '" class="' + (!done && i === d.round ? 'cur' : '') + '">' + PM.ROUND_NAMES[i] + '</button>').join('') + '</div>';
    const reveal = ui.justPlayed && showRound === Math.min(ui.round, d.rounds.length - 1);
    h += '<div class="matches' + (reveal ? ' reveal' : '') + '">' + d.rounds[showRound].map((m, i) => matchRow(d, m, i, ui.drawG, showRound)).join('') + '</div>';
    if (done) h += '<div class="cta-bar"><button class="btn block" data-a="close-tournament">Cerrar torneo y avanzar</button></div>';
    return h;
  }

  function matchRow(d, m, i, g, r) {
    const A = d.pairs[m.a], B = d.pairs[m.b], res = m.res;
    const wA = res && res.winner === 'A';
    const nm = (P, cls) => '<span class="tm ' + cls + '"><span class="n">' + esc(P.label) + '</span>' + (P.isUser ? '<span class="you">Tú</span>' : '') + '</span>';
    let h = '<button class="match' + (A.isUser || B.isUser ? ' mine' : '') + '" style="--i:' + i + '"' + (res ? ' data-a="match" data-g="' + g + '" data-r="' + r + '" data-i="' + i + '"' : ' disabled') + '>' +
      nm(A, res ? (wA ? 'w' : 'l') : '') + nm(B, res ? (wA ? 'l' : 'w') : '');
    h += res
      ? '<span class="sc" style="grid-row:1/3;grid-column:2">' + res.sets.map((s) => '<div><b class="' + (s[0] > s[1] ? '' : 'lose') + '">' + s[0] + '</b><b class="' + (s[1] > s[0] ? '' : 'lose') + '">' + s[1] + '</b></div>').join('') + '</span>'
      : '<span class="pending">Por jugar</span>';
    return h + '</button>';
  }

  function resultCard(T) {
    const r = T.result;
    let h = '<div class="sec">Resultado</div><div class="result-card"><h3>' + esc(T.t.name) + '</h3><div class="result-grid">';
    ['M', 'F'].forEach((g) => {
      const x = r.res[g];
      h += '<div><span class="g">' + (g === 'M' ? 'Masculino' : 'Femenino') + '</span><b>' + exitText(x.exit, true) + '</b><span class="gain">' + money(x.prize) + ' y ' + x.points + ' puntos</span></div>';
    });
    h += '</div><div class="tot"><span>Premios menos inscripciones</span><b class="num">' + (r.net >= 0 ? '+' : '') + money(r.net) + '</b></div>';
    if (r.promoted != null) h += '<p style="margin-top:10px;color:var(--ball);font-weight:700">Ascenso al ' + PM.TIER_NAMES[r.promoted] + '.</p>';
    return h + '</div>';
  }

  function matchSheet(g, rIdx, i) {
    const T = S.tournament, d = T.draws[g], m = d.rounds[rIdx][i], res = m.res;
    const A = d.pairs[m.a], B = d.pairs[m.b], wA = res.winner === 'A';
    const line = (P, tac, sets, idx, win) =>
      '<div class="bl' + (win ? ' win' : '') + '"><div class="n">' + esc(P.label) + (win ? '<span class="wdot" title="Ganadores"></span>' : '') + '<small>Táctica ' + PM.TACTICS[tac].name.toLowerCase() + '</small></div>' +
      [0, 1, 2].map((k) => sets[k] ? '<b class="' + (sets[k][idx] > sets[k][1 - idx] ? 'won' : '') + '">' + sets[k][idx] + '</b>' : '<b></b>').join('') + '</div>';
    let h = '<h2>' + PM.ROUND_NAMES[rIdx] + (g === 'M' ? ' masculinos' : ' femeninos') + '</h2><div class="muted small">' + esc(T.t.name) + ', ' + res.totalGames + ' juegos</div>';
    h += '<div class="board">' + line(A, res.tacticA, res.sets, 0, wA) + line(B, res.tacticB, res.sets, 1, !wA) + '</div>';
    h += '<div class="sec">Claves del partido</div><ul class="why">' + res.why.map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul>';
    [[A, res.gainA], [B, res.gainB]].forEach((x) => {
      if (x[0].isUser) h += '<p class="muted small" style="margin-top:14px">Tu pareja acumuló ' + x[1].map((v, k) => '+' + Math.round(v) + '% (' + esc(x[0].players[k].first) + ')').join(' y ') + ' de cansancio.</p>';
    });
    return h;
  }

  function weekSheet(sum) {
    const net = sum.sponsor - sum.wages - sum.staff - sum.upkeep;
    let h = '<h2>Semana ' + sum.week + ' cerrada</h2><div class="muted small">' + (sum.rested ? 'Semana de descanso.' : 'Así acaba la semana.') + '</div>';
    h += '<div class="facts"><div><b class="num">+' + money(sum.sponsor).replace(' €', '') + '</b><span>Patrocinio</span></div><div><b class="num">−' + money(sum.wages + sum.staff + sum.upkeep).replace(' €', '') + '</b><span>Sueldos y gastos</span></div><div><b class="num">' + Math.round(sum.recovered) + '</b><span>Cansancio recuperado</span></div></div>';
    h += '<div class="sec">Entrenamiento</div>';
    h += sum.gains.length ? '<ul class="why">' + sum.gains.map((x) => '<li><span><b>' + esc(x.name) + '</b>: ' + Object.keys(x.g).map((k) => LBL[k].toLowerCase() + ' +' + x.g[k]).join(', ') + '</span></li>').join('') + '</ul>'
      : '<p class="muted small">Nadie ha subido una estadística entera esta semana. El progreso se acumula.</p>';
    h += '<div class="actions"><button class="btn block" data-a="close">Ver la nueva semana</button></div>';
    return h;
  }

  /* ---------- render ---------- */
  function render(o) {
    o = o || {};
    if (!S) { renderWelcome(); return; }
    const v = $('#view');
    v.classList.remove('no-pad');
    renderTop(); renderNav();
    const st = v.scrollTop;
    const views = { club: viewClub, squad: viewSquad, torneo: viewTorneo, academia: viewAcademia, mercado: viewMercado };
    v.innerHTML = views[ui.tab]();
    v.scrollTop = o.top ? 0 : st;
    ui.justPlayed = false;
    if (ui.sheetFn) refreshSheet();
  }
  function setTab(t) {
    ui.tab = t;
    render({ top: true });
  }

  /* ---------- acciones ---------- */
  const A = {
    tab: (d) => setTab(d.t),
    close: () => closeSheet(),
    crest: (d) => { ui.crest = +d.i; document.querySelectorAll('[data-a="crest"]').forEach((b, i) => b.setAttribute('aria-pressed', String(i === ui.crest))); },
    seg: (d) => { if (d.k === 'drawG') { ui.drawG = d.v; ui.round = Math.min(ui.round, S.tournament.draws[d.v].rounds.length - 1); } else ui[d.k] = d.v; render(); },
    player: (d) => openSheet(() => playerSheet(getP(d.id))),
    'player-court': (d) => {
      const c = ui.entry ? S.offers[ui.entry.offer].court : null;
      openSheet(() => playerSheet(getP(d.id), { court: c }));
    },
    'market-player': (d) => openSheet(() => playerSheet(S.market.find((p) => p.id === d.id), { market: true })),
    focus: (d) => { getP(d.id).focus = d.k; save(); refreshSheet(); },
    sign: (d) => {
      const p = S.market.find((x) => x.id === d.id), price = PM.valueOf(p);
      if (S.players.length >= D.MAX_SQUAD) return toast('Plantilla completa.');
      if (S.money < price) return toast('No tienes dinero suficiente.');
      S.money -= price; S.players.push(p); S.market = S.market.filter((x) => x.id !== d.id);
      addLog('Fichas a ' + p.name + ' por ' + money(price) + '.');
      save(); closeSheet(); render(); toast(p.first + ' ya es de los tuyos.');
    },
    'sell-ask': (d) => {
      const p = getP(d.id);
      if (S.tournament) return toast('No puedes vender durante un torneo.');
      if (byGender(p.gender).length <= 2) return toast('Necesitas al menos dos ' + (p.gender === 'M' ? 'hombres' : 'mujeres') + '.');
      confirmSheet({ title: '¿Vender a ' + p.first + '?', text: 'Recibirás ' + money(Math.round(PM.valueOf(p) * 0.65)) + '. No se puede deshacer.', ok: 'Vender', action: 'sell', data: 'data-id="' + p.id + '"', danger: true });
    },
    sell: (d) => {
      const p = getP(d.id), price = Math.round(PM.valueOf(p) * 0.65);
      S.money += price; S.players = S.players.filter((x) => x.id !== d.id);
      addLog('Vendes a ' + p.name + ' por ' + money(price) + '.');
      save(); closeSheet(); render(); toast('Vendido por ' + money(price));
    },
    'upgrade-staff': (d) => {
      const k = d.k, def = D.STAFF[k], l = S.staff[k], cost = def.costs[l];
      if (S.money < cost) return toast('No tienes dinero suficiente.');
      S.money -= cost; S.staff[k] = l + 1;
      addLog('Fichas a ' + def.coaches[l][0] + ' como ' + def.name.toLowerCase() + '.');
      save(); render(); toast(def.coaches[l][0] + ' se une al club.');
    },
    'upgrade-fac': (d) => {
      const k = d.k, def = D.FAC[k], l = S.fac[k], cost = def.costs[l];
      if (S.money < cost) return toast('No tienes dinero suficiente.');
      S.money -= cost; S.fac[k] = l + 1;
      addLog(def.name + ' sube al nivel ' + (l + 1) + '.');
      save(); render(); toast(def.name + ': nivel ' + (l + 1));
    },
    'goto-offer': (d) => { ui.tab = 'torneo'; A['pick-offer'](d); },
    'pick-offer': (d) => {
      const i = +d.i, c = S.offers[i].court;
      ui.entry = { offer: i, M: autoPick('M', c), F: autoPick('F', c) };
      ui.entry.tM = recTactic('M', c); ui.entry.tF = recTactic('F', c);
      ui.tab = 'torneo';
      render({ top: true });
    },
    'entry-back': () => { ui.entry = null; render({ top: true }); },
    pick: (d) => {
      const e = ui.entry, p = getP(d.id), g = p.gender, c = S.offers[e.offer].court;
      if (e[g].includes(d.id)) e[g] = e[g].filter((x) => x !== d.id);
      else { e[g].push(d.id); if (e[g].length > 2) e[g].shift(); }
      if (e[g].length === 2) e['t' + g] = recTactic(g, c);
      render();
    },
    autopick: (d) => {
      const e = ui.entry, c = S.offers[e.offer].court;
      e[d.g] = autoPick(d.g, c); e['t' + d.g] = recTactic(d.g, c);
      render();
    },
    tactic: (d) => {
      if (S.tournament) S.tournament.draws[d.g].pairs['USER_' + d.g].tactic = d.t;
      else ui.entry['t' + d.g] = d.t;
      save(); render();
    },
    enter: () => startTournament(),
    'play-round': () => playRound(),
    'sim-end': () => simToEnd(),
    round: (d) => { ui.round = +d.i; render(); },
    match: (d) => openSheet(() => matchSheet(d.g, +d.r, +d.i)),
    'close-tournament': () => {
      S.tournament = null;
      const sum = endWeek(false);
      ui.tab = 'club'; render({ top: true });
      openSheet(() => weekSheet(sum));
    },
    'rest-ask': () => confirmSheet({ title: '¿Descansar esta semana?', text: 'No juegas ningún torneo. La plantilla recupera 25 puntos de cansancio extra y entrena un 50% más. Seguirás pagando sueldos.', ok: 'Descansar la semana', action: 'rest' }),
    rest: () => {
      closeSheet();
      const sum = endWeek(true);
      addLog('Semana de descanso en el club.');
      ui.tab = 'club'; render({ top: true });
      setTimeout(() => openSheet(() => weekSheet(sum)), 320);
    },
    'reset-ask': () => confirmSheet({ title: '¿Empezar de nuevo?', text: 'Se borrará tu club, tu plantilla y tus resultados. No se puede deshacer.', ok: 'Borrar y empezar', action: 'reset', danger: true }),
    reset: () => {
      try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* nada */ }
      S = null; closeSheet(); ui.tab = 'club'; ui.entry = null; render();
    }
  };

  document.addEventListener('click', (ev) => {
    const el = ev.target.closest('[data-a]');
    if (!el || el.disabled) return;
    const fn = A[el.dataset.a];
    if (fn) fn(el.dataset, el);
  });
  document.addEventListener('keydown', (ev) => {
    if ((ev.key === 'Enter' || ev.key === ' ') && ev.target.matches && ev.target.matches('[role="button"][data-a]')) {
      ev.preventDefault(); ev.target.click();
    }
  });
  document.addEventListener('submit', (ev) => {
    if (ev.target.id !== 'newgame') return;
    ev.preventDefault();
    const name = (ev.target.club.value || '').trim() || 'Club Pádel Costa';
    newGame(name, ui.crest);
    render({ top: true });
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden && S) save(); });

  /* ---------- botón atrás de Android (si está el plugin de Capacitor) ---------- */
  function setupBackButton() {
    const cap = window.Capacitor;
    const app = cap && cap.Plugins && cap.Plugins.App;
    if (!app || !app.addListener) return;
    app.addListener('backButton', () => {
      if (ui.sheetFn) return closeSheet();
      if (ui.entry && !S.tournament) { ui.entry = null; return render({ top: true }); }
      if (ui.tab !== 'club') return setTab('club');
      if (app.exitApp) app.exitApp();
    });
  }

  /* ---------- arranque ---------- */
  S = load();
  render();
  setupBackButton();

  // ayuda para pruebas en navegador
  window.__pm = { get state() { return S; }, ui: ui, render: render, actions: A };
})();
