/* Datos del club: cuerpo técnico e instalaciones. Todos los nombres son inventados. */
window.PM_DATA = {
  STAFF: {
    tec: {
      name: 'Entrenador de técnica',
      blurb: 'Acelera el progreso de remate, volea, bandeja y saque.',
      perLevel: '+18% de progreso en golpes',
      costs: [2500, 6000, 12000, 22000, 40000],
      wages: [120, 260, 480, 800, 1300],
      coaches: [
        ['Manolo Prieto', 'Monitor del club de barrio. Paciente y práctico.'],
        ['Irene Vallejo', 'Excompetidora del circuito regional.'],
        ['Santiago Rueda', 'Técnico de la selección juvenil.'],
        ['Elisa Montaner', 'Entrenadora de campeones de Europa.'],
        ['Gaspar Lemos', 'Leyenda de la pista. Ve el golpe antes de que ocurra.']
      ]
    },
    tac: {
      name: 'Entrenador de táctica',
      blurb: 'Mejora defensa, globo y mente, y la sintonía de las parejas.',
      perLevel: '+18% de progreso y +0,5 de sinergia',
      costs: [2500, 6000, 12000, 22000, 40000],
      wages: [120, 260, 480, 800, 1300],
      coaches: [
        ['Ricardo Pons', 'Analiza vídeo de los rivales cada noche.'],
        ['Nerea Olazábal', 'Especialista en parejas de perfil opuesto.'],
        ['Jaime Cantero', 'Estratega de torneos por eliminatorias.'],
        ['Teresa Bolaños', 'Lee el partido en dos juegos.'],
        ['Anselmo Quirós', 'El mejor analista del circuito.']
      ]
    },
    fis: {
      name: 'Preparador físico',
      blurb: 'Sube el aguante y reduce el cansancio que se acumula en cada partido.',
      perLevel: '+18% de progreso en aguante y −3% de cansancio',
      costs: [2500, 6000, 12000, 22000, 40000],
      wages: [120, 260, 480, 800, 1300],
      coaches: [
        ['Hugo Rebollo', 'Entrenador personal de gimnasio.'],
        ['Marina Echave', 'Licenciada en ciencias del deporte.'],
        ['Gerardo Sanz', 'Preparador de atletas de élite.'],
        ['Amparo Vidal', 'Doctora en fisiología del esfuerzo.'],
        ['Bruno Calatrava', 'Su método se estudia en la federación.']
      ]
    }
  },
  FAC: {
    pistas: {
      name: 'Pistas de entrenamiento',
      blurb: 'Más pistas y mejor superficie. Todo el equipo progresa más rápido.',
      perLevel: '+10% de progreso general por nivel',
      costs: [3000, 7000, 14000, 26000, 45000]
    },
    recup: {
      name: 'Centro de recuperación',
      blurb: 'Fisioterapia y descanso. Los jugadores llegan más frescos al siguiente torneo.',
      perLevel: '+5 de recuperación semanal por nivel',
      costs: [3000, 7000, 14000, 26000, 45000]
    },
    cantera: {
      name: 'Cantera y ojeo',
      blurb: 'Mejores jugadores y más candidatos cada semana en el mercado.',
      perLevel: 'Más calidad y más fichajes disponibles',
      costs: [3000, 7000, 14000, 26000, 45000]
    }
  },
  UPKEEP_PER_LEVEL: 40,
  MAX_SQUAD: 10,
  CRESTS: [
    { id: 'azul', a: '#1E55C6', b: '#DDEB3B' },
    { id: 'coral', a: '#E4572E', b: '#FFFFFF' },
    { id: 'verde', a: '#14A06F', b: '#0C2760' },
    { id: 'violeta', a: '#6B4FD8', b: '#DDEB3B' },
    { id: 'negro', a: '#16213D', b: '#F0A21C' }
  ]
};
